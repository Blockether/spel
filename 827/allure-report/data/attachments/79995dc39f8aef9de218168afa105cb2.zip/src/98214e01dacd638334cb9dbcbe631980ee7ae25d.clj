(ns com.blockether.spel.smoke-test
  "End-to-end smoke tests against example.org.

   Showcases the Allure in-test API with epics, features, stories, steps,
   screenshots, parameters, attachments, and links. Run with the Allure
   reporter for rich HTML output:

     clojure -M:test --output nested --output com.blockether.spel.allure-reporter/allure"
  (:require
   [clojure.string :as str]
   [com.blockether.spel.allure :as allure :refer [around defdescribe describe expect it]]
   [com.blockether.spel.assertions :as assert]
   [com.blockether.spel.example-domain :as example]
   [com.blockether.spel.locator :as locator]
   [com.blockether.spel.network :as net]
   [com.blockether.spel.page :as page]
   [com.blockether.spel.snapshot :as snapshot]
   [com.blockether.spel.core :as core])
  (:import
   [com.microsoft.playwright Response]))

;; =============================================================================
;; Example.com — Smoke Tests
;; =============================================================================

(defdescribe example-com-navigation-smoke-test
  "Smoke: example.org navigation and HTTP response"
  (around [f] (core/with-testing-browser (f)))

  (describe "HTTP response inspection"

    (it "returns HTTP 200 with valid headers"

      (core/with-testing-page [pg] (allure/epic "Smoke Tests")
        (allure/feature "example.org")
        (allure/story "Navigation")
        (allure/severity :blocker)
        (allure/owner "spel")
        (allure/tag "smoke")
        (allure/tag "example.org")
        (allure/link "Site" "https://example.org")
        (allure/description
          "Navigates to example.org and validates HTTP response status,
        headers, URL, and body content. This is the most basic smoke
        test — if this fails, the internet is down.")

        (allure/step "Navigate to example.org"
          (println "[navigate] Starting navigation to example.org")
          (let [resp (page/navigate pg "https://example.org")]
            (println "[navigate] Navigation complete, response received")
            (allure/parameter "url" "https://example.org")
            (expect (instance? Response resp))

            (allure/step "Verify HTTP status 200"
              (let [status (net/response-status resp)]
                (println "[status] HTTP status:" status)
                (allure/parameter "status" status)
                (expect (= 200 status))))

            (allure/step "Verify response OK"
              (expect (true? (net/response-ok? resp))))

            (allure/step "Verify response URL"
              (let [url (net/response-url resp)]
                (println "[url] Response URL:" url)
                (allure/parameter "response-url" url)
                (expect (.contains ^String url "example.org"))))

            (allure/step "Verify content-type header"
              (let [headers (net/response-headers resp)
                    ct (get headers "content-type")]
                (println "[headers] Content-Type:" ct)
                (allure/parameter "content-type" ct)
                (expect (some? ct))
                (expect (.contains ^String ct "text/html"))))

            (allure/step "Verify response body is non-empty"
              (let [body (net/response-text resp)]
                (println "[body] Body length:" (count body) "chars")
                (allure/parameter "body-length" (count body))
                (expect (pos? (count body)))))))

        (allure/step "Screenshot after navigation"
          (allure/screenshot pg "example.org loaded"))))))

(defdescribe example-com-content-smoke-test
  "Smoke: example.org page content and DOM structure"
  (around [f] (core/with-testing-browser (f)))

  (describe "page title, content, and structure"

    (it "has correct title and heading"

      (core/with-testing-page [pg] (allure/epic "Smoke Tests")
        (allure/feature "example.org")
        (allure/story "Content Verification")
        (allure/severity :critical)
        (allure/tag "smoke")
        (allure/tag "example.org")

        (allure/step "Navigate"
          (println "Loading example.org...")
          (example/route! pg)
          (page/navigate pg "https://example.org")
          (println "Page loaded successfully"))

        (allure/step "Verify page title"
          (let [title (page/title pg)]
            (println "Page title:" (pr-str title))
            (allure/parameter "title" title)
            (expect (= "Example Domain" title))))

        (allure/step "Verify page URL"
          (let [url (page/url pg)]
            (println "Current URL:" url)
            (allure/parameter "url" url)
            (expect (.contains ^String url "example.org"))))

        (allure/step "Verify H1 heading"
          (let [h1 (page/locator pg "h1")
                text (locator/text-content h1)]
            (println "H1 text:" (pr-str text))
            (println "H1 visible?" (locator/is-visible? h1))
            (allure/parameter "h1.text" text)
            (expect (= "Example Domain" text))
            (expect (locator/is-visible? h1))))

        (allure/step "Verify paragraph text mentions 'domain'"
          (let [p (locator/first-element (page/locator pg "p"))
                text (locator/text-content p)]
            (println "Paragraph text:" (subs text 0 (min 60 (count text))) "...")
            (allure/parameter "p.text" text)
            (expect (.contains ^String text "domain"))))))

    (it "has a 'Learn more' link to IANA"

      (core/with-testing-page [pg] (allure/epic "Smoke Tests")
        (allure/feature "example.org")
        (allure/story "Content Verification")
        (allure/severity :normal)
        (allure/tag "smoke")

        (allure/step "Navigate"
          (page/navigate pg "https://example.org"))

        (allure/step "Find the link"
          (let [link (page/locator pg "a")]
            (allure/step "Verify link text"
              (let [text (locator/text-content link)]
                (allure/parameter "link.text" text)
                (expect (.contains ^String text "Learn more"))))

            (allure/step "Verify link href points to IANA"
              (let [href (locator/get-attribute link "href")]
                (allure/parameter "link.href" href)
                (expect (.contains ^String href "iana.org"))))

            (allure/step "Verify link is visible and enabled"
              (expect (locator/is-visible? link))
              (expect (locator/is-enabled? link)))

            (allure/step "Verify exactly 1 link on the page"
              (let [n (locator/count-elements link)]
                (allure/parameter "link.count" n)
                (expect (= 1 n))))))

        (allure/step "Screenshot of page with link"
          (allure/screenshot pg "example.org link"))))))

(defdescribe example-com-assertions-smoke-test
  "Smoke: Playwright assertions against example.org"
  (around [f] (core/with-testing-browser (f)))

  (describe "Playwright built-in assertions"

    (it "passes all Playwright assertions"

      (core/with-testing-page [pg] (allure/epic "Smoke Tests")
        (allure/feature "example.org")
        (allure/story "Playwright Assertions")
        (allure/severity :critical)
        (allure/tag "smoke")
        (allure/tag "assertions")

        (allure/step "Navigate"
          (println "Opening example.org for assertion tests...")
          (example/route! pg)
          (page/navigate pg "https://example.org")
          (println "Ready for assertions"))

        (allure/step "Page assertions"
          (println "Running page-level Playwright assertions...")
          (allure/step "has-title matches 'Example Domain'"
            (println "Asserting title = 'Example Domain'")
            (assert/has-title pg "Example Domain"))

          (allure/step "has-url contains 'example.org'"
            (println "Asserting URL contains 'example.org'")
            (assert/has-url pg #"example\.org"))
          (println "All page assertions passed"))

        (allure/step "Locator assertions on H1"
          (let [h1 (page/locator pg "h1")]
            (println "Locator: h1 — running 4 assertions")
            (allure/step "has-text 'Example Domain'"
              (assert/has-text h1 "Example Domain"))

            (allure/step "is-visible"
              (assert/is-visible h1))

            (allure/step "is-enabled"
              (assert/is-enabled h1))

            (allure/step "has-count 1"
              (assert/has-count h1 1))
            (println "All H1 assertions passed ✓")))

        (allure/step "Locator assertions on link"
          (let [link (page/locator pg "a")]
            (println "Locator: a — checking text and href")
            (allure/step "contains-text 'Learn more'"
              (assert/contains-text link "Learn more"))

            (allure/step "has-attribute href containing 'iana.org'"
              (assert/has-attribute link "href" "https://iana.org/domains/example"))
            (println "Link assertions passed ✓")))

        (allure/step "Negated assertions"
          (let [ghost (page/locator pg "#does-not-exist")
                la    (assert/assert-that ghost)
                neg   (assert/loc-not la)]
            (println "Testing negated assertion: #does-not-exist should NOT be visible")
            (allure/step "not is-visible for non-existent element"
              (assert/is-visible neg))
            (println "Negated assertion passed ✓")))))))

;; =============================================================================
;; Example.com — JavaScript & Screenshot
;; =============================================================================

(defdescribe example-com-evaluate-smoke-test
  "Smoke: JavaScript evaluation and screenshot capture"
  (around [f] (core/with-testing-browser (f)))

  (describe "evaluate and screenshot"

    (it "evaluates JS and captures full-page screenshot"

      (core/with-testing-page [pg] (allure/epic "Smoke Tests")
        (allure/feature "example.org")
        (allure/story "JS Evaluation & Screenshots")
        (allure/severity :normal)
        (allure/tag "smoke")
        (allure/tag "javascript")

        (allure/step "Navigate"
          (println "Loading example.org for JS evaluation tests...")
          (example/route! pg)
          (page/navigate pg "https://example.org"))

        (allure/step "Read document.title via JS"
          (let [title (page/evaluate pg "document.title")]
            (println "document.title =" (pr-str title))
            (allure/parameter "document.title" title)
            (expect (= "Example Domain" title))))

        (allure/step "Read heading text via JS"
          (let [text (page/evaluate pg "document.querySelector('h1').textContent")]
            (println "h1.textContent =" (pr-str text))
            (allure/parameter "h1.textContent" text)
            (expect (= "Example Domain" text))))

        (allure/step "Count links via JS"
          (let [count (page/evaluate pg "document.querySelectorAll('a').length")]
            (println "Found" count "link(s) on page")
            (allure/parameter "link-count" count)
            (expect (= 1 count))))

        (allure/step "Read viewport dimensions"
          (let [vp (page/viewport-size pg)]
            (println "Viewport:" (:width vp) "x" (:height vp))
            (allure/parameter "viewport.width" (:width vp))
            (allure/parameter "viewport.height" (:height vp))
            (expect (pos? (:width vp)))
            (expect (pos? (:height vp)))))

        (allure/step "Capture full-page screenshot"
          (println "Taking full-page screenshot...")
          (allure/screenshot pg "example.org full page"))

        (allure/step "Attach page HTML as text"
          (let [html (page/content pg)]
            (println "Page HTML size:" (count html) "chars")
            (allure/attach "Page HTML" html "text/html")))))))

;; =============================================================================
;; Example.com — Accessibility Snapshots & Ref-Based Interaction
;; =============================================================================

(defdescribe example-com-snapshot-smoke-test
  "Smoke: accessibility snapshots and ref-based interaction on example.org"
  (around [f] (core/with-testing-browser (f)))

  (describe "capture snapshot and interact via refs"

    (it "captures accessibility tree with numbered refs"

      (core/with-testing-page [pg] (allure/epic "Smoke Tests")
        (allure/feature "example.org")
        (allure/story "Accessibility Snapshots")
        (allure/severity :critical)
        (allure/owner "spel")
        (allure/tag "smoke")
        (allure/tag "snapshot")
        (allure/link "Site" "https://example.org")
        (allure/description
          "Captures the accessibility snapshot of example.org, verifies the
        tree structure contains expected elements with refs, and resolves
        refs back to Playwright locators for interaction.")

        (allure/step "Navigate to example.org"
          (example/route! pg)
          (page/navigate pg "https://example.org")
          (page/wait-for-load-state pg "load"))

        (allure/step "Capture accessibility snapshot"
          (let [snap (snapshot/capture-snapshot pg)]
            (allure/parameter "ref-count" (:counter snap))
            (allure/attach "Accessibility Tree" (:tree snap) "text/plain")

            (allure/step "Verify snapshot structure"
              (expect (map? snap))
              (expect (string? (:tree snap)))
              (expect (map? (:refs snap)))
              (expect (pos? (:counter snap))))

            (allure/step "Tree contains heading 'Example Domain'"
              (expect (.contains ^String (:tree snap) "Example Domain")))

            (allure/step "Tree contains a link element"
              (expect (.contains ^String (:tree snap) "link")))

            (allure/step "Refs map has entries"
              (let [ref-count (count (:refs snap))]
                (println "Snapshot has" ref-count "refs")
                (allure/parameter "refs" ref-count)
                (expect (pos? ref-count))))))

        (allure/step "Screenshot with snapshot overlay"
          (allure/screenshot pg "example.org accessibility"))))

    (it "resolves snapshot refs to working locators"

      (core/with-testing-page [pg] (allure/epic "Smoke Tests")
        (allure/feature "example.org")
        (allure/story "Accessibility Snapshots")
        (allure/severity :critical)
        (allure/tag "smoke")
        (allure/tag "snapshot")

        (allure/step "Navigate"
          (example/route! pg)
          (page/navigate pg "https://example.org"))

        (allure/step "Capture snapshot and resolve refs"
          (let [snap (snapshot/capture-snapshot pg)
                refs (:refs snap)]

            (allure/step "Find the heading ref"
              (let [heading-entry (first (filter (fn [[_ v]] (= "heading" (:role v)))
                                           refs))
                    heading-ref   (first heading-entry)]
                (println "Heading ref:" heading-ref)
                (allure/parameter "heading-ref" heading-ref)
                (expect (some? heading-ref))

                (allure/step "Resolve ref to locator and read text"
                  (let [loc  (snapshot/resolve-ref pg heading-ref)
                        text (locator/text-content loc)]
                    (println "Resolved heading text:" (pr-str text))
                    (allure/parameter "heading-text" text)
                    (expect (= "Example Domain" text))
                    (expect (locator/is-visible? loc))))))

            (allure/step "Find the link ref"
              (let [link-entry (first (filter (fn [[_ v]] (= "link" (:role v)))
                                        refs))
                    link-ref   (first link-entry)]
                (println "Link ref:" link-ref)
                (allure/parameter "link-ref" link-ref)
                (expect (some? link-ref))

                (allure/step "Resolve ref to locator and verify href"
                  (let [loc  (snapshot/resolve-ref pg link-ref)
                        href (locator/get-attribute loc "href")]
                    (println "Resolved link href:" href)
                    (allure/parameter "link-href" href)
                    (expect (.contains ^String href "iana.org"))
                    (expect (locator/is-visible? loc))))))))))))

;; =============================================================================
;; Example.com — Navigation Flow & History
;; =============================================================================

(defdescribe example-com-navigation-flow-smoke-test
  "Smoke: navigation flow — click link, go back, go forward"
  (around [f] (core/with-testing-browser (f)))

  (describe "full navigation cycle"

    (it "clicks the IANA link, navigates away, and returns via back/forward"

      (core/with-testing-page [pg] (allure/epic "Smoke Tests")
        (allure/feature "example.org")
        (allure/story "Navigation Flow")
        (allure/severity :critical)
        (allure/tag "smoke")
        (allure/tag "navigation")
        (allure/description
          "Tests the full navigation lifecycle: load page → click outbound
        link → verify new page → go back → verify original page → go
        forward → verify we're back on the target page.")

        (allure/step "Navigate to example.org"
          (page/navigate pg "https://example.org")
          (assert/has-title pg "Example Domain")
          (allure/screenshot pg "Step 1: example.org loaded"))

        (allure/step "Click the 'Learn more' link"
          (let [link (page/get-by-text pg "Learn more")]
            (assert/is-visible link)
            (locator/click link)
            (page/wait-for-load-state pg "domcontentloaded")))

        (allure/step "Verify navigated to IANA"
          (let [url (page/url pg)]
            (println "After click URL:" url)
            (allure/parameter "iana-url" url)
            (expect (.contains ^String url "iana.org"))
            (allure/screenshot pg "Step 2: IANA page")))

        (allure/step "Go back to example.org"
          (page/go-back pg)
          (page/wait-for-load-state pg "domcontentloaded")
          (let [url (page/url pg)]
            (println "After back URL:" url)
            (allure/parameter "back-url" url)
            (expect (.contains ^String url "example.org")))
          (assert/has-title pg "Example Domain")
          (allure/screenshot pg "Step 3: back to example.org"))

        (allure/step "Go forward to IANA again"
          (page/go-forward pg)
          (page/wait-for-load-state pg "domcontentloaded")
          (let [url (page/url pg)]
            (println "After forward URL:" url)
            (allure/parameter "forward-url" url)
            (expect (.contains ^String url "iana.org")))
          (allure/screenshot pg "Step 4: forward to IANA"))))

    (it "reload preserves the page"

      (core/with-testing-page [pg] (allure/epic "Smoke Tests")
        (allure/feature "example.org")
        (allure/story "Navigation Flow")
        (allure/severity :normal)
        (allure/tag "smoke")
        (allure/tag "navigation")

        (allure/step "Navigate to example.org"
          (example/route! pg)
          (page/navigate pg "https://example.org"))

        (allure/step "Reload the page"
          (page/reload pg)
          (page/wait-for-load-state pg "load"))

        (allure/step "Verify page is intact after reload"
          (assert/has-title pg "Example Domain")
          (assert/has-text (page/locator pg "h1") "Example Domain")
          (let [url (page/url pg)]
            (allure/parameter "url-after-reload" url)
            (expect (.contains ^String url "example.org")))))))

  (describe "network inspection during navigation"

    (it "inspects request and response details for navigation"

      (core/with-testing-page [pg] (allure/epic "Smoke Tests")
        (allure/feature "example.org")
        (allure/story "Network Inspection")
        (allure/severity :normal)
        (allure/tag "smoke")
        (allure/tag "network")
        (allure/description
          "Navigates to example.org and inspects the HTTP request/response
        chain: method, headers, timing, and body content.")

        (allure/step "Navigate and capture response"
          (let [resp (page/navigate pg "https://example.org")]
            (expect (instance? Response resp))

            (allure/step "Inspect request details"
              (let [req    (net/response-request resp)
                    method (net/request-method req)
                    url    (net/request-url req)]
                (println "Request:" method url)
                (allure/parameter "request-method" method)
                (allure/parameter "request-url" url)
                (expect (= "GET" method))
                (expect (.contains ^String url "example.org"))
                (expect (true? (net/request-is-navigation? req)))))

            (allure/step "Inspect response headers"
              (let [headers (net/response-headers resp)]
                (println "Response headers:" (count headers) "entries")
                (allure/parameter "header-count" (count headers))
                (allure/attach "Response Headers"
                  (str/join "\n" (map (fn [[k v]] (str k ": " v)) headers))
                  "text/plain")
                (expect (some? (get headers "content-type")))))

            (allure/step "Inspect response body"
              (let [body (net/response-text resp)]
                (println "Response body:" (count body) "chars")
                (allure/parameter "body-length" (count body))
                (expect (pos? (count body)))
                (expect (.contains ^String body "Example Domain"))))))))))
