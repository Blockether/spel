(ns com.blockether.spel.allure-reporter
  "Allure 3 reporter for Lazytest with embedded Playwright trace viewer.

   Writes JSON result files to allure-results/, then automatically generates
   the full HTML report to allure-report/ using Allure 3 CLI (prefers a global
   install, falls back to npx with pinned 3.3.1). The report embeds a local
   Playwright trace viewer so trace
   attachments load instantly without trace.playwright.dev.

   Usage:
     clojure -M:test --output com.blockether.spel.allure-reporter/allure
     clojure -M:test --output nested --output com.blockether.spel.allure-reporter/allure

   Output directory defaults to allure-results/. Override with:
     -Dlazytest.allure.output=path/to/dir
     LAZYTEST_ALLURE_OUTPUT=path/to/dir"
  (:require
   [clojure.java.io :as io]
   [clojure.string :as str]
   [clojure.test :as ct]
   [com.blockether.spel.allure :as allure]
   [com.blockether.spel.driver :as driver]
   [com.blockether.spel.spel-allure-alternative-html-report :as alternative-report]
   [lazytest.expectation-failed :refer [ex-failed?]]
   [lazytest.reporters :refer [reporter-dispatch]]
   [lazytest.suite :as s]
   [lazytest.test-case :as tc])
  (:import
   [java.io File PrintWriter StringWriter]
   [java.net InetAddress]
   [java.security MessageDigest]
   [java.util UUID]))

;; =============================================================================
;; Run State
;; =============================================================================

(def ^:private run-state
  "Mutable state captured during the test run."
  (atom {}))

;; =============================================================================
;; Per-Test Output Capture (alter-var-root hack)
;; =============================================================================

(defn- explicit-allure-steps?
  "True when steps include something other than automatic network activity."
  [steps]
  (boolean (some #(not= "Network Activity" (:name %)) steps)))

(defn- wrap-try-test-case
  "Wraps try-test-case to capture *out*/*err* and bind the Allure
   in-test API context per test case. Also captures trace/HAR paths
   from the current dynamic bindings (set by with-traced-page fixture).

   When the test body does not create any explicit allure steps
   (via step/api-step/ui-step), auto-generates a single synthetic
   step from the test result so the Allure report never shows
   'No test steps information available'."
  [original-fn]
  (fn [tc]
    (let [out-sw      (StringWriter.)
          err-sw      (StringWriter.)
          ctx-atom    (atom (allure/make-context))
          network-log (atom [])
          ;; Capture trace/HAR/video paths (bound by fixture dynamic vars)
          trace-path  allure/*trace-path*
          har-path    allure/*har-path*
          video-path  allure/*video-path*
          start-ms    (System/currentTimeMillis)
          result      (binding [*out*                (PrintWriter. out-sw true)
                                *err*                (PrintWriter. err-sw true)
                                allure/*context*     ctx-atom
                                allure/*output-dir*  (:output-dir @run-state)
                                allure/*test-title*  (tc/identifier tc)
                                allure/*test-out*    out-sw
                                allure/*test-err*    err-sw
                                allure/*network-log* network-log]
                        (try
                          (original-fn tc)
                          (finally
                            (allure/flush-network-steps!))))
          stop-ms     (System/currentTimeMillis)
          ;; Auto-generate a step when the test has no explicit allure steps.
          ;; Automatic network activity is report detail and must not hide the
          ;; test result, timing, or failure details.
          _           (when-not (explicit-allure-steps? (:steps @ctx-atom))
                        (let [tc-name (tc/identifier tc)
                              status  (case (:type result)
                                        :pass    "passed"
                                        :fail    (if (and (some? (:thrown result))
                                                       (not (ex-failed? (:thrown result))))
                                                   "broken"
                                                   "failed")
                                        :pending "skipped"
                                        "unknown")
                              ;; stdout lines → ⏵ marker sub-steps
                              out-str  (str out-sw)
                              out-subs (into []
                                         (comp (filter (complement str/blank?))
                                           (map (fn [line]
                                                  {:name   (str "⏵ " line)
                                                   :status "passed"
                                                   :start  stop-ms
                                                   :stop   stop-ms
                                                   :steps  []
                                                   :attachments []
                                                   :parameters  []})))
                                         (when-not (str/blank? out-str)
                                           (str/split-lines out-str)))
                              ;; stderr lines → ⚠ marker sub-steps
                              err-str  (str err-sw)
                              err-subs (into []
                                         (comp (filter (complement str/blank?))
                                           (map (fn [line]
                                                  {:name   (str "⚠ " line)
                                                   :status "passed"
                                                   :start  stop-ms
                                                   :stop   stop-ms
                                                   :steps  []
                                                   :attachments []
                                                   :parameters  []})))
                                         (when-not (str/blank? err-str)
                                           (str/split-lines err-str)))
                              ;; For failed tests: expected/actual/message as params
                              params   (cond-> []
                                         (:expected result)
                                         (conj {:name "expected" :value (pr-str (:expected result))})
                                         (some? (:actual result))
                                         (conj {:name "actual" :value (pr-str (:actual result))})
                                         (:message result)
                                         (conj {:name "message" :value (str (:message result))}))
                              auto-step (cond-> {:name         tc-name
                                                 :status       status
                                                 :start        start-ms
                                                 :stop         stop-ms
                                                 :steps        (into out-subs err-subs)
                                                 :attachments  []
                                                 :parameters   params}
                                          (= :fail (:type result))
                                          (assoc :statusDetails
                                            {:message (or (:message result)
                                                        (when-let [^Throwable t (:thrown result)]
                                                          (.getMessage t))
                                                        "Test failed")}))]
                          (swap! ctx-atom update :steps conj auto-step)))
          ctx-val     @ctx-atom]
      (cond-> (assoc result
                :system-out    (str out-sw)
                :system-err    (str err-sw)
                :allure/context ctx-val)
        trace-path (assoc :allure/trace-path (str trace-path))
        har-path   (assoc :allure/har-path   (str har-path))
        video-path (assoc :allure/video-path (str video-path))))))

(defn- install-output-capture!
  "Patches try-test-case for output capture. Skips if already patched
   (e.g., by the JUnit reporter running alongside)."
  []
  (when-not (:original-try-test-case @run-state)
    (let [original (deref #'tc/try-test-case)]
      (swap! run-state assoc :original-try-test-case original)
      (alter-var-root #'tc/try-test-case wrap-try-test-case))))

(defn- uninstall-output-capture!
  "Restores the original try-test-case function."
  []
  (when-let [original (:original-try-test-case @run-state)]
    (alter-var-root #'tc/try-test-case (constantly original))))

;; =============================================================================
;; Helpers
;; =============================================================================

(defn- hostname
  ^String []
  (try (.getHostName (InetAddress/getLocalHost))
       (catch Exception _ "localhost")))

(defn- uuid
  ^String []
  (str (UUID/randomUUID)))

(defn- md5-hex
  "MD5 hash of a string, returned as lowercase hex."
  ^String [^String s]
  (let [md (MessageDigest/getInstance "MD5")
        bytes (.digest md (.getBytes s "UTF-8"))]
    (apply str (map #(format "%02x" (bit-and (int %) 0xff)) bytes))))

(defn- stacktrace-str
  "Serializes a Throwable (plus its cause chain) as a full stack trace
   string with NO `... N common frames omitted` elision.

   `Throwable.printStackTrace` deduplicates frames that appear at the
   tail of a cause's stack when they match the wrapping exception, but
   in CI reports we want the complete frames for every cause — the
   abbreviated output hides the actual call path in the caused-by
   exception, which is exactly what an on-call reader needs."
  ^String [^Throwable t]
  (when t
    (let [sb (StringBuilder.)
          append-exception (fn append-exception [^Throwable ex prefix]
                             (.append sb ^String prefix)
                             (.append sb (str ex))
                             (.append sb \newline)
                             (doseq [^StackTraceElement el (.getStackTrace ex)]
                               (.append sb "\tat ")
                               (.append sb (str el))
                               (.append sb \newline))
                             (doseq [^Throwable s (.getSuppressed ex)]
                               (append-exception s "\tSuppressed: "))
                             (when-let [c (.getCause ex)]
                               (append-exception c "Caused by: ")))]
      (append-exception t "")
      (str sb))))

;; =============================================================================
;; JSON Emitter (no external deps)
;; =============================================================================

(defn- json-escape
  "Escape a string for JSON."
  ^String [^String s]
  (-> s
    (str/replace "\\" "\\\\")
    (str/replace "\"" "\\\"")
    (str/replace "\n" "\\n")
    (str/replace "\r" "\\r")
    (str/replace "\t" "\\t")))

(defn- ->json-pretty
  "Convert to JSON with basic indentation for readability."
  ^String [v]
  (let [indent (fn indent [v depth]
                 (let [depth (long depth)
                       pad (apply str (repeat (* depth 2) " "))
                       pad1 (apply str (repeat (* (inc depth) 2) " "))]
                   (cond
                     (nil? v)     "null"
                     (string? v)  (str "\"" (json-escape v) "\"")
                     (number? v)  (str v)
                     (boolean? v) (if v "true" "false")
                     (keyword? v) (indent (name v) depth)

                     (map? v)
                     (if (empty? v)
                       "{}"
                       (str "{\n"
                         (->> v
                           (map (fn [[k val]]
                                  (str pad1
                                    (indent (if (keyword? k) (name k) (str k)) (inc depth))
                                    ": "
                                    (indent val (inc depth)))))
                           (str/join ",\n"))
                         "\n" pad "}"))

                     (sequential? v)
                     (if (empty? v)
                       "[]"
                       (str "[\n"
                         (->> v
                           (map (fn [item] (str pad1 (indent item (inc depth)))))
                           (str/join ",\n"))
                         "\n" pad "]"))

                     :else (indent (str v) depth))))]
    (indent v 0)))

;; =============================================================================
;; Result Tree Walking (shared with JUnit reporter pattern)
;; =============================================================================

(defn- doc-str
  [doc]
  (cond
    (instance? clojure.lang.Namespace doc) (str (ns-name doc))
    (instance? clojure.lang.Var doc)       (str (:name (meta doc)))
    (and (some? doc)
      (not (str/blank? (str doc))))     (str doc)
    :else                                  nil))

(defn- ns-suite?
  [result]
  (and (s/suite-result? result)
    (= :lazytest/ns (-> result :source :type))))

(defn- collect-test-cases
  "Walk result tree depth-first, collecting leaf test case results.
   Each result is annotated with:
     ::path     - vector of describe/suite doc strings
     ::ns-name  - the namespace name string"
  [result path ns-name]
  (if (s/suite-result? result)
    (let [source-type (-> result :source :type)
          doc (doc-str (:doc result))
          new-ns (if (= :lazytest/ns source-type)
                   (or doc ns-name)
                   ns-name)
          new-path (if (and doc
                         (not= :lazytest/run source-type)
                         (not= :lazytest/ns source-type))
                     (conj path doc)
                     path)]
      (mapcat #(collect-test-cases % new-path new-ns) (:children result)))
    ;; Leaf test-case result
    [(assoc result ::path path ::ns-name ns-name)]))

(defn- ns-package
  ^String [^String ns-name]
  (let [idx (.lastIndexOf ns-name ".")]
    (if (pos? idx) (subs ns-name 0 idx) "")))

;; =============================================================================
;; Result Classification
;; =============================================================================

(defn- allure-status
  "Map Lazytest result type to Allure status string."
  ^String [tc]
  (case (:type tc)
    :pass    "passed"
    :fail    (if (and (some? (:thrown tc))
                   (not (ex-failed? (:thrown tc))))
               "broken"
               "failed")
    :pending "skipped"
    "unknown"))

;; =============================================================================
;; Allure Result Construction
;; =============================================================================

(defn- build-status-details
  "Build statusDetails map for failed/broken tests."
  [tc]
  (when (= :fail (:type tc))
    (let [^Throwable thrown (:thrown tc)
          msg (or (:message tc)
                (when thrown (.getMessage thrown))
                "Test failed")
          expected (pr-str (:expected tc))
          actual   (pr-str (:actual tc))
          trace    (stacktrace-str thrown)]
      (cond-> {:message (str msg
                          (when (:expected tc)
                            (str "\nExpected: " expected
                              "\nActual: " actual)))}
        trace (assoc :trace trace)))))

(defn- build-labels
  "Build labels array for a test case result."
  [tc]
  (let [ns-name  (::ns-name tc)
        path     (::path tc)
        pkg      (when ns-name (ns-package ns-name))
        sub      (first path)
        hn       (:hostname @run-state)]
    (cond-> []
      ns-name (conj {:name "suite" :value ns-name})
      pkg     (conj {:name "parentSuite" :value pkg})
      sub     (conj {:name "subSuite" :value sub})
      hn      (conj {:name "host" :value hn})
      true    (conj {:name "thread" :value "main"})
      true    (conj {:name "language" :value "clojure"})
      true    (conj {:name "framework" :value "lazytest"})
      pkg     (conj {:name "package" :value pkg})
      ns-name (conj {:name "testClass" :value ns-name})
      true    (conj {:name "testMethod" :value (tc/identifier tc)}))))

(defn- build-full-name
  "Build a stable fullName for historyId/testCaseId generation."
  ^String [tc]
  (let [ns-name (::ns-name tc)
        path    (::path tc)
        name    (tc/identifier tc)
        parts   (filterv some? (concat [ns-name] path [name]))]
    (str/join "." parts)))

(defn- build-display-name
  "Build a human-readable test name."
  ^String [tc]
  (let [path (::path tc)
        name (tc/identifier tc)]
    (if (seq path)
      (str (str/join " > " path) " > " name)
      name)))

(defn- write-attachment!
  "Write an attachment file, return the attachment metadata map, or nil."
  [output-dir content att-name]
  (when (and content (not (str/blank? content)))
    (let [att-uuid (uuid)
          filename (str att-uuid "-attachment.txt")
          att-file (io/file output-dir filename)]
      (spit att-file content)
      {:name att-name :source filename :type "text/plain"})))

(defn- copy-file-attachment!
  "Copy a file into the output dir and return an attachment metadata map.
   Returns nil if the source file doesn't exist or is empty."
  [^File output-dir ^String source-path att-name ^String mime-type ^String ext]
  (let [src (io/file source-path)]
    (when (and (.exists src) (pos? (.length src)))
      (let [att-uuid (uuid)
            filename (str att-uuid "-attachment" ext)
            dest     (io/file output-dir filename)]
        (io/copy src dest)
        {:name att-name :source filename :type mime-type}))))

(defn- strip-step-stack
  "Remove internal :step-stack from step trees (not part of Allure schema)."
  [steps]
  (mapv (fn [step]
          (-> step
            (dissoc :step-stack)
            (update :steps strip-step-stack)))
    steps))

(defn- build-result
  "Build a complete Allure result map for a single test case."
  [tc output-dir]
  (let [result-uuid (uuid)
        full-name   (build-full-name tc)
        duration-ns (long (or (:lazytest.runner/duration tc) 0))
        duration-ms (long (/ duration-ns 1e6))
        stop-ms     (+ (long (:start-ms @run-state 0)) duration-ms)
        ;; Use test-level start/stop approximation
        ;; Allure cares about relative ordering for timeline
        start-ms    (- stop-ms duration-ms)
        status-det  (build-status-details tc)
         ;; Write full test-level log (accumulated from all steps via tee-writer)
        out-att     (write-attachment! output-dir (:system-out tc) "Full stdout log")
        err-att     (write-attachment! output-dir (:system-err tc) "Full stderr log")
        ;; Copy trace/HAR/video files if present (from fixture dynamic vars)
        trace-att   (when-let [tp (:allure/trace-path tc)]
                      (copy-file-attachment! output-dir tp "Playwright Trace"
                        "application/vnd.allure.playwright-trace" ".zip"))
        har-att     (when-let [hp (:allure/har-path tc)]
                      (copy-file-attachment! output-dir hp "Network Activity (HAR)"
                        "application/json" ".har"))
        video-att   (when-let [vp (:allure/video-path tc)]
                      (copy-file-attachment! output-dir vp "Video Recording"
                        "video/webm" ".webm"))
        io-atts     (filterv some? [out-att err-att trace-att har-att video-att])
        ;; In-test API context data
        ctx         (:allure/context tc)
        ctx-labels  (when ctx (:labels ctx))
        ctx-links   (when ctx (:links ctx))
        ctx-params  (when ctx (:parameters ctx))
        ctx-atts    (when ctx (:attachments ctx))
        ctx-steps   (when ctx (strip-step-stack (:steps ctx)))
        ctx-desc    (when ctx (:description ctx))
        ;; Merge reporter labels with in-test API labels
        all-labels  (into (build-labels tc) ctx-labels)
        all-links   (or (seq ctx-links) [])
        all-params  (or (seq ctx-params) [])
        all-atts    (into (vec io-atts) ctx-atts)]
    (cond-> {:uuid        result-uuid
             :historyId   (md5-hex full-name)
             :testCaseId  (md5-hex full-name)
             :fullName    full-name
             :name        (build-display-name tc)
             :status      (allure-status tc)
             :stage       "finished"
             :start       start-ms
             :stop        stop-ms
             :labels      all-labels
             :parameters  all-params
             :links       all-links}
      status-det        (assoc :statusDetails status-det)
      (seq all-atts)    (assoc :attachments all-atts)
      (seq ctx-steps)   (assoc :steps ctx-steps)
      ctx-desc          (assoc :description ctx-desc))))

;; =============================================================================
;; Supplementary Files
;; =============================================================================

(defn- spel-version
  "Reads the spel version from the SPEL_VERSION classpath resource.
   Returns nil when the resource is not on the classpath (e.g. consumer projects)."
  []
  (some-> (io/resource "SPEL_VERSION") slurp str/trim not-empty))

(defn- project-version
  "User-configurable project version for Allure reports.
   Checked via system property, env var, then falls back to spel version."
  []
  (or (System/getProperty "lazytest.allure.version")
    (System/getenv "LAZYTEST_ALLURE_VERSION")
    (spel-version)))

(defn- write-environment-properties!
  "Write environment.properties to the allure output directory."
  [^File output-dir]
  (let [version (project-version)
        commit-author (System/getenv "COMMIT_AUTHOR")
        props   (cond-> [["java.version"    (System/getProperty "java.version")]
                         ["java.vendor"     (System/getProperty "java.vendor")]
                         ["os.name"         (System/getProperty "os.name")]
                         ["os.arch"         (System/getProperty "os.arch")]
                         ["os.version"      (System/getProperty "os.version")]
                         ["clojure.version" (clojure-version)]
                         ["file.encoding"   (System/getProperty "file.encoding")]]
                  (spel-version)
                  (conj ["spel.version" (spel-version)])
                  version
                  (conj ["project.version" version])
                  commit-author
                  (conj ["commit.author" commit-author]))
        content (->> props
                  (map (fn [[k v]] (str k " = " (or v ""))))
                  (str/join "\n"))]
    (spit (io/file output-dir "environment.properties") (str content "\n"))))

(defn- write-categories-json!
  "Write categories.json to classify failures vs unexpected errors."
  [^File output-dir]
  (let [categories [{:name "Assertion failures"
                     :matchedStatuses ["failed"]
                     :messageRegex ".*"}
                    {:name "Unexpected errors"
                     :matchedStatuses ["broken"]
                     :messageRegex ".*"}]]
    (spit (io/file output-dir "categories.json")
      (->json-pretty categories))))

;; =============================================================================
;; HTML Report Generation & Trace Viewer Embedding
;; =============================================================================

(defn report-dir
  ^String []
  (or (System/getProperty "lazytest.allure.report")
    (System/getenv "LAZYTEST_ALLURE_REPORT")
    "allure-report"))

(defn- copy-trace-viewer!
  "Copy the embedded Playwright trace viewer from classpath resources
   into the Allure report directory.  Reads `trace-viewer/MANIFEST`
   (a newline-delimited list of relative paths) and copies each entry
   via `io/resource`, so this works from both the filesystem and a JAR."
  [^File dest]
  (when-let [manifest-url (io/resource "trace-viewer/MANIFEST")]
    (let [entries (->> (slurp manifest-url)
                    str/split-lines
                    (map str/trim)
                    (remove str/blank?))]
      (doseq [entry entries]
        (when-let [res (io/resource (str "trace-viewer/" entry))]
          (let [target (io/file dest entry)]
            (.mkdirs (.getParentFile target))
            (with-open [in (io/input-stream res)]
              (io/copy in target)))))
      (pos? (count entries)))))

(defn- patch-trace-viewer-url!
  "Rewrite the Allure app JS to point the Playwright Trace Viewer iframe
   at the local ./trace-viewer/ directory instead of trace.playwright.dev."
  [^File report]
  (doseq [^File f (.listFiles report)]
    (when (and (.isFile f)
            (str/starts-with? (.getName f) "app-")
            (str/ends-with? (.getName f) ".js"))
      (let [content (slurp f)
            patched (-> content
                      (str/replace "src:\"https://trace.playwright.dev/next/\""
                        "src:\"./trace-viewer/\"")
                      (str/replace ",\"https://trace.playwright.dev\"" ",\"*\""))]
        (when (not= content patched)
          (spit f patched))))))

(defn- patch-sw-safari-compat!
  "Patch the trace viewer Service Worker to fix Safari iframe compatibility.

   Safari's Service Worker does not reflect history.pushState() changes
   for iframe clients — self.clients.get(id).url returns the original
   URL without ?trace=<blob>. The Playwright SW's loadTrace function
   reads the trace URL from the client URL's searchParams and throws
   'trace parameter is missing' when it's absent.

   The fix: when searchParams lacks ?trace=, fall back to the cached
   clientId→traceUrl map ($e) that was populated by an earlier /contexts
   request (which DOES have ?trace= in the request URL)."
  [^File report]
  (let [sw (io/file report "trace-viewer" "sw.bundle.js")]
    (when (.isFile sw)
      (let [content (slurp sw)]
        ;; Guard: skip if already patched (replacement contains the search
        ;; pattern as a substring, so str/replace would re-match).
        (when-not (str/includes? content "n=$e.get(s)")
          (let [patched (str/replace content
                          "if(!n)throw new Error(\"trace parameter is missing\")"
                          "if(!n){n=$e.get(s);if(!n)throw new Error(\"trace parameter is missing\")}")]
            (when (not= content patched)
              (spit sw patched))))))))

(defn- patch-sw-safari-transform-stream!
  "Patch the trace viewer Service Worker to fix Safari TransformStream
   subclassing bug (WebKit Bug 226201).

   The Playwright SW bundles zip.js which defines classes that extend the
   native TransformStream Web API (CRC32 verification, codec streams, etc.).
   Safari has an unfixed bug where extending built-in classes like
   TransformStream, WritableStream, ReadableStream, WebSocket, Request, and
   Response fails — the native constructor doesn't properly create own
   data properties on subclass instances. In strict mode (service workers
   always run in strict mode) this throws:

     TypeError: Attempted to assign to readonly property

   because TransformStream.prototype.readable and .writable are getter-only
   and Safari fails to shadow them with own data properties on the instance.

   The fix: prepend a shim that detects the bug at runtime and replaces
   TransformStream with a wrapper constructor that returns a plain JS
   object (via Object.create) delegating readable/writable to a native
   instance stored in a WeakMap. The plain object is extensible, so
   expando writes, super.readable, and Object.defineProperty all work.

   The detection test exercises three patterns that zip.js actually uses:
     1. Expando property write (`this.__probe = 1`) — tests extensibility
     2. `super.readable` access — tests prototype getter delegation
     3. `Object.defineProperty(this, 'readable', ...)` — tests shadowing
        the prototype getter with an own accessor (used by zip.js `ls()`)
   Older Safari may pass a trivial `new (class extends TransformStream {})`
   but fail on these real-world patterns, so the probe must be rigorous."
  [^File report]
  (let [sw (io/file report "trace-viewer" "sw.bundle.js")]
    (when (.isFile sw)
      (let [content (slurp sw)
            shim    (str
                      ;; Self-invoking function to avoid polluting global scope.
                      ;; Tests TransformStream subclassing with the three patterns
                      ;; that zip.js uses; patches only when any of them fail.
                      "(function(){"
                      "if(typeof TransformStream==='undefined')return;"
                      "try{"
                      "var T=class extends TransformStream{"
                      "constructor(){"
                      "super({transform:function(){}});"
                      ;; 1) expando write — zip.js does this.outputSize=0
                      "this.__probe=1;"
                      "if(this.__probe!==1)throw 1;"
                      ;; 2) super.readable — zip.js reads the prototype getter
                      "var r=super.readable;"
                      "if(!r||typeof r.getReader!=='function')throw 1;"
                      ;; 3) Object.defineProperty — zip.js ls() shadows readable
                      "Object.defineProperty(this,'readable',"
                      "{configurable:true,get:function(){return r}})}};"
                      "new T()"
                      "}catch(e){"
                      "var _TS=TransformStream;"
                      "var _m=new WeakMap();"
                      "var _p=Object.create(_TS.prototype);"
                      "Object.defineProperty(_p,'readable',"
                      "{configurable:true,enumerable:true,"
                      "get:function(){return _m.get(this).readable}});"
                      "Object.defineProperty(_p,'writable',"
                      "{configurable:true,enumerable:true,"
                      "get:function(){return _m.get(this).writable}});"
                      "self.TransformStream=function TransformStream(t,w,r){"
                      "var s=new _TS(t,w,r);"
                      "var o=Object.create(new.target?new.target.prototype:_p);"
                      "_m.set(o,s);"
                      "Object.defineProperty(o,'readable',"
                      "{configurable:true,enumerable:true,"
                      "get:function(){return s.readable}});"
                      "Object.defineProperty(o,'writable',"
                      "{configurable:true,enumerable:true,"
                      "get:function(){return s.writable}});"
                      "return o};"
                      "self.TransformStream.prototype=_p;"
                      "Object.setPrototypeOf(self.TransformStream,_TS)"
                      "}"
                      "}());\n")
            patched (str shim content)]
        (when (not= content patched)
          (spit sw patched))))))

(defn- patch-sw-safari-response-headers!
  "Patch the trace viewer Service Worker to fix Safari Response.headers
   immutability.

   After serving a snapshot, the Playwright SW does:

     response.headers.set('Content-Security-Policy', 'upgrade-insecure-requests')

   on an already-constructed Response object. Safari enforces stricter
   immutability on Response headers than Chrome/Firefox — even on responses
   created via `new Response()`. The fix: construct a new Response with the
   CSP header included, instead of mutating the existing response's headers."
  [^File report]
  (let [sw (io/file report "trace-viewer" "sw.bundle.js")]
    (when (.isFile sw)
      (let [content (slurp sw)
            ;; Original (minified):
            ;;   return Fn&&_.headers.set("Content-Security-Policy","upgrade-insecure-requests"),_
            ;; Patched:
            ;;   return Fn?new Response(_.body,{status:_.status,statusText:_.statusText,
            ;;     headers:[..._.headers.entries()].concat([["Content-Security-Policy",
            ;;     "upgrade-insecure-requests"]])}):_
            patched (str/replace content
                      "Fn&&_.headers.set(\"Content-Security-Policy\",\"upgrade-insecure-requests\"),_"
                      (str "Fn?new Response(_.body,{status:_.status,statusText:_.statusText,"
                        "headers:[..._.headers.entries()].concat([[\"Content-Security-Policy\","
                        "\"upgrade-insecure-requests\"]])}):_"))]
        (when (not= content patched)
          (spit sw patched))))))

(defn- inject-trace-viewer-prewarm!
  "Inject an inline script into the report's index.html that eagerly
   registers the Playwright trace viewer's Service Worker.

   The trace viewer relies on a SW (sw.bundle.js) to intercept fetch
   requests and serve trace data. On first visit the SW must be
   registered, installed, and controlling the scope before the viewer
   can load a trace. The viewer waits for `navigator.serviceWorker.controller`
   but Allure posts the trace blob on the iframe's `load` event — if the
   SW isn't active yet, the `fetch('contexts?...')` call inside the viewer
   falls through to the HTTP server, returning HTML instead of trace data,
   which causes 'End of central directory not found' ZIP parse errors.

   This script registers the SW directly from the parent page (no iframe
   overhead) and waits for it to claim clients. By the time the user
   clicks a trace attachment, the SW is already active and controlling
   the ./trace-viewer/ scope."
  [^File report]
  (let [idx (io/file report "index.html")]
    (when (.isFile idx)
      (let [content  (slurp idx)
            prewarm  (str "\n<script>\n"
                       "// Pre-register Playwright trace viewer Service Worker.\n"
                       "// Starts immediately on page load so the SW is active and\n"
                       "// controlling the scope before any trace attachment is opened.\n"
                       "(function(){\n"
                       "  if(!navigator.serviceWorker)return;\n"
                       "  navigator.serviceWorker.register('./trace-viewer/sw.bundle.js',\n"
                       "    {scope:'./trace-viewer/'}).catch(function(){});\n"
                       "}());\n"
                       "</script>\n")
            patched  (str/replace content "</head>" (str prewarm "</head>"))]
        (when (not= content patched)
          (spit idx patched))))))

(defn- inject-video-modal!
  "Inject video player modal into the Allure report's index.html.
   Enables inline video playback for video/webm attachments."
  [^File report]
  (let [idx (io/file report "index.html")]
    (when (.isFile idx)
      (let [content (slurp idx)]
        (when-not (str/includes? content "id=\"videoModal\"")
          (let [css      (str "\n<style>\n"
                           ".video-modal{display:none;position:fixed;inset:0;background:rgba(0,0,0,0.9);z-index:9999;align-items:center;justify-content:center}\n"
                           ".video-modal.show{display:flex}\n"
                           ".video-modal-content{max-width:90vw;max-height:90vh;position:relative}\n"
                           ".video-modal video{max-width:100%;max-height:85vh;border-radius:8px;background:#000}\n"
                           ".video-modal-close{position:absolute;top:-40px;right:0;background:none;border:none;color:#fff;font-size:1.5rem;cursor:pointer}\n"
                           ".video-modal-title{position:absolute;bottom:20px;left:20px;right:60px;color:#fff;font-size:0.9rem;background:rgba(0,0,0,0.6);padding:0.5rem 1rem;border-radius:4px}\n"
                           "</style>\n")
                modal-html (str "\n<div id=\"videoModal\" class=\"video-modal\" onclick=\"if(event.target===this)closeVideoModal()\">\n"
                             "<div class=\"video-modal-content\">\n"
                             "<button class=\"video-modal-close\" onclick=\"closeVideoModal()\">&times;</button>\n"
                             "<video id=\"videoPlayer\" controls playsinline></video>\n"
                             "<div id=\"videoModalTitle\" class=\"video-modal-title\"></div>\n"
                             "</div>\n"
                             "</div>\n")
                js (str "<script>\n"
                     "function openVideoModal(e,t){var n=document.getElementById('videoModal'),r=document.getElementById('videoPlayer'),a=document.getElementById('videoModalTitle');r.src=e,a.textContent=t||'Video',n.classList.add('show'),r.play()}\n"
                     "function closeVideoModal(){var e=document.getElementById('videoModal'),t=document.getElementById('videoPlayer');t.pause(),t.src='',e.classList.remove('show')}\n"
                     "document.addEventListener('keydown',function(e){'Escape'===e.key&&closeVideoModal()});\n"
                     "// Intercept video attachment clicks to open in modal\n"
                     "(function(){\n"
                     "  var observer=new MutationObserver(function(){document.querySelectorAll('a[href]').forEach(function(link){if(link.href&&link.href.match(/\\.webm($|\\?)|video\\//i)){link.onclick=function(e){e.preventDefault();openVideoModal(link.href,link.textContent.trim()||'Video Recording')}}})});\n"
                     "  observer.observe(document.body,{childList:true,subtree:true});\n"
                     "  setTimeout(function(){document.querySelectorAll('a[href]').forEach(function(link){if(link.href&&link.href.match(/\\.webm($|\\?)|video\\//i)){link.onclick=function(e){e.preventDefault();openVideoModal(link.href,link.textContent.trim()||'Video Recording')}}})},3000);\n"
                     "}());\n"
                     "</script>\n")
                patched (-> content
                          (str/replace "</head>" (str css "</head>"))
                          (str/replace "<body>" (str "<body>" modal-html))
                          (str/replace "</body>" (str js "</body>")))]
            (when (not= content patched)
              (spit idx patched))))))))

(defn- inject-markdown-renderer!
  "Inject inline Markdown rendering for text/markdown attachments.
   Allure 3 renders markdown as raw <pre><code class=\"language-md\"> blocks.
   This injects a MutationObserver that converts them to styled HTML inline,
   with HTTP exchange-aware styling (request/response/cURL cards with copy).
   Follows the same pattern as inject-video-modal!."
  [^File report]
  (let [idx (io/file report "index.html")]
    (when (.isFile idx)
      (let [content (slurp idx)]
        (when-not (str/includes? content "id=\"spel-md-renderer\"")
          (let [css
                (str
                  "\n<style id=\"spel-md-css\">\n"
                  ;; Base container
                  ".spel-md{font-family:var(--font-family,system-ui);line-height:1.6;padding:0;font-size:.9rem;margin-top:12px}\n"

                  ;; HTTP title bar — method + url + status
                  ".spel-md .http-title{display:flex;align-items:center;gap:8px;padding:10px 14px;margin:0;"
                  "border-radius:8px 8px 0 0;background:var(--bg-control-secondary,#f0f0f0);"
                  "border-bottom:2px solid var(--border-secondary,#ddd)}\n"
                  ".spel-md .http-method{display:inline-block;padding:2px 8px;border-radius:4px;"
                  "font-weight:700;font-size:.8em;font-family:var(--font-family-mono,monospace);"
                  "color:#fff;text-transform:uppercase;flex-shrink:0}\n"
                  ".spel-md .http-method.get{background:#61affe}"
                  ".spel-md .http-method.post{background:#49cc90}"
                  ".spel-md .http-method.put{background:#fca130}"
                  ".spel-md .http-method.patch{background:#50e3c2}"
                  ".spel-md .http-method.delete{background:#f93e3e}"
                  ".spel-md .http-method.head{background:#9012fe}"
                  ".spel-md .http-method.options{background:#0d5aa7}\n"
                  ".spel-md .http-url{font-family:var(--font-family-mono,monospace);font-size:.85em;"
                  "color:var(--text-primary,#333);word-break:break-all;min-width:0}\n"
                  ".spel-md .http-status{margin-left:auto;white-space:nowrap;font-weight:600;"
                  "font-size:.85em;padding:2px 10px;border-radius:4px;flex-shrink:0}\n"
                  ".spel-md .http-status.s2xx{background:#e6f9ee;color:#1a7f37}"
                  ".spel-md .http-status.s3xx{background:#fff3cd;color:#856404}"
                  ".spel-md .http-status.s4xx{background:#fce4e4;color:#c0392b}"
                  ".spel-md .http-status.s5xx{background:#fce4e4;color:#c0392b}\n"

                  ;; Request / Response cards — distinct visual panels
                  ".spel-md .http-card{margin:6px 0 0;border-radius:8px;border:1px solid var(--border-secondary,#e0e0e0);"
                  "overflow:hidden}\n"
                  ".spel-md .http-card:first-of-type{margin-top:0}\n"
                  ".spel-md .http-card .card-hdr{display:flex;align-items:center;gap:6px;padding:6px 12px;"
                  "font-size:.75em;font-weight:700;text-transform:uppercase;letter-spacing:.6px;"
                  "cursor:pointer;list-style:none;user-select:none}\n"
                  ".spel-md .http-card .card-hdr::-webkit-details-marker{display:none}\n"
                  ".spel-md .http-card.req .card-hdr{background:rgba(73,204,144,.12);color:#1a7f37;"
                  "border-bottom:1px solid rgba(73,204,144,.25)}\n"
                  ".spel-md .http-card.res .card-hdr{background:rgba(97,175,254,.12);color:#1565c0;"
                  "border-bottom:1px solid rgba(97,175,254,.25)}\n"
                  ".spel-md .http-card.curl .card-hdr{background:rgba(252,161,48,.12);color:#a35d00;"
                  "border-bottom:1px solid rgba(252,161,48,.25)}\n"
                  ".spel-md .card-icon{font-size:1.1em}\n"
                  ".spel-md .card-chevron{margin-left:auto;font-size:1.1em;transition:transform .15s ease}\n"
                  ".spel-md .http-card[open] .card-chevron{transform:rotate(90deg)}\n"
                  ".spel-md .http-card .card-body{padding:0}\n"

                  ;; Sections inside cards
                  ".spel-md .http-section{padding:8px 12px;border-top:1px solid var(--border-secondary,#eee)}\n"
                  ".spel-md .http-section:first-child{border-top:none}\n"
                  ".spel-md .section-hdr{display:flex;align-items:center;gap:6px;margin:0 0 4px;"
                  "font-size:.75em;font-weight:600;text-transform:uppercase;letter-spacing:.4px;"
                  "color:var(--text-secondary,#888)}\n"

                  ;; Code blocks with copy button
                  ".spel-md .code-wrap{position:relative;margin:4px 0 0}\n"
                  ".spel-md .code-wrap pre{margin:0;border-radius:6px;padding:10px 14px 10px 14px;"
                  "background:var(--bg-control-secondary,#f5f5f5);overflow-x:auto}\n"
                  ".spel-md .code-wrap pre code{background:none;padding:0;"
                  "font-family:var(--font-family-mono,monospace);font-size:.85em;line-height:1.5}\n"
                  ".spel-md .copy-btn{position:absolute;top:4px;right:4px;padding:3px 8px;"
                  "border:1px solid var(--border-secondary,#ccc);border-radius:4px;"
                  "background:var(--bg-control-secondary,#f5f5f5);color:var(--text-secondary,#666);"
                  "font-size:.7em;cursor:pointer;"
                  "font-family:var(--font-family,system-ui)}\n"
                  ".spel-md .copy-btn:hover{background:var(--bg-control-primary,#e0e0e0)}\n"
                  ".spel-md .copy-btn.copied{color:#1a7f37;border-color:#49cc90}\n"

                  ;; Generic markdown fallbacks
                  ".spel-md h2{font-size:1em;font-weight:600;margin:1em 0 .4em}\n"
                  ".spel-md h3{font-size:.9em;font-weight:600;margin:.6em 0 .3em;color:var(--text-secondary,#666)}\n"
                  ".spel-md code{background:var(--bg-control-secondary,#f5f5f5);padding:1px 5px;border-radius:3px;font-size:.9em}\n"
                  ".spel-md p{margin:.3em 0}\n"
                  ".spel-md hr{border:none;border-top:1px solid var(--border-secondary,#e0e0e0);margin:1em 0}\n"
                  ".spel-md strong{font-weight:600}\n"

                  ;; Step type badges — [API], [UI], [UI+API]
                  ".spel-badge{display:inline-block;padding:1px 6px;border-radius:4px;"
                  "font-size:.7em;font-weight:900;font-family:system-ui,-apple-system,'Segoe UI',Roboto,sans-serif;letter-spacing:.03em;margin-right:8px;"
                  "vertical-align:middle;line-height:1.6}\n"
                  ".spel-badge.api{background:#e8f4fd;color:#1976d2;border:1px solid #90caf9}\n"
                  ".spel-badge.ui{background:#f3e8fd;color:#7b1fa2;border:1px solid #ce93d8}\n"
                  ".spel-badge.ui-api{background:#fff3e0;color:#e65100;border:1px solid #ffcc80}\n"
                  "</style>\n")

                js
                (str
                  "<script id=\"spel-md-renderer\">\n"
                  "(function(){\n"

                  ;; HTML-escape
                  "function esc(s){return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}\n"

                  ;; Parse HTTP title line: ## METHOD url → status statusText
                  "function parseHttpTitle(line){\n"
                  "  var m=line.match(/^##\\s+(GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS)\\s+(.+?)\\s*\\u2192\\s*(\\d+)\\s*(.*)$/);\n"
                  "  if(!m)return null;\n"
                  "  return{method:m[1],url:m[2],status:parseInt(m[3]),statusText:m[4].trim()}\n"
                  "}\n"

                  ;; Detect section type from ### heading
                  "function sectionType(heading){\n"
                  "  var h=heading.toLowerCase();\n"
                  "  if(h==='curl')return{type:'curl',label:'cURL'};\n"
                  "  if(/^request/.test(h))return{type:'req',label:heading};\n"
                  "  if(/^response/.test(h))return{type:'res',label:heading};\n"
                  "  return null;\n"
                  "}\n"

                  ;; Status class helper
                  "function statusCls(code){\n"
                  "  if(code>=200&&code<300)return 's2xx';\n"
                  "  if(code>=300&&code<400)return 's3xx';\n"
                  "  if(code>=400&&code<500)return 's4xx';\n"
                  "  return 's5xx';\n"
                  "}\n"

                  ;; Card icons
                  "var cardIcon={req:'\\u2191',res:'\\u2193',curl:'\\u2706'};\n"
                  "var cardTitle={req:'Request',res:'Response',curl:'cURL'};\n"

                  ;; Code block with copy button
                  "function codeBlock(lang,code){\n"
                  "  return '<div class=\"code-wrap\"><button class=\"copy-btn\" onclick=\"spelCopy(this)\">Copy</button>'"
                  "+'<pre><code class=\"language-'+(lang||'text')+'\">'+esc(code)+'</code></pre></div>';\n"
                  "}\n"

                  ;; Main markdown → HTML renderer (HTTP-exchange aware)
                  ;; Handles: headings (# through ######), fenced code blocks,
                  ;; ordered / unordered lists, blockquotes, inline bold / italic
                  ;; / code / links, horizontal rules, and the HTTP exchange
                  ;; cards when the doc follows the `## METHOD URL → STATUS`
                  ;; convention.
                  "function inline(s){\n"
                  "  return esc(s)"
                  ".replace(/\\[([^\\]]+)\\]\\(([^)]+)\\)/g,'<a href=\"$2\" target=\"_blank\" rel=\"noopener\">$1</a>')"
                  ".replace(/\\*\\*([^*]+)\\*\\*/g,'<strong>$1</strong>')"
                  ".replace(/(^|[^*])\\*([^*\\n]+)\\*(?=[^*]|$)/g,'$1<em>$2</em>')"
                  ".replace(/`([^`]+)`/g,'<code>$1</code>');\n"
                  "}\n"
                  "function spelMd(s){\n"
                  "  var lines=s.split('\\n'),tokens=[],inCode=false,codeLang='',codeLines=[];\n"

                  ;; Pass 1: tokenize lines into structured tokens
                  "  for(var i=0;i<lines.length;i++){\n"
                  "    var L=lines[i];\n"
                  "    if(!inCode&&/^```/.test(L)){inCode=true;codeLang=L.slice(3).trim();codeLines=[];continue}\n"
                  "    if(inCode){if(/^```/.test(L)){inCode=false;"
                  "tokens.push({t:'code',lang:codeLang,text:codeLines.join('\\n')});continue}"
                  "codeLines.push(L);continue}\n"
                  "    if(/^---+$/.test(L)){tokens.push({t:'hr'});continue}\n"
                  "    var ht=(/^## /.test(L))?parseHttpTitle(L):null;\n"
                  "    if(ht){tokens.push({t:'http-title',d:ht});continue}\n"
                  "    var hm=L.match(/^(#{1,6})\\s+(.*)$/);\n"
                  "    if(hm){var lvl=hm[1].length;"
                  "var sec=(lvl===3)?sectionType(hm[2].trim()):null;"
                  "if(sec){tokens.push({t:'section',sec:sec});continue}"
                  "tokens.push({t:'h'+lvl,text:hm[2]});continue}\n"
                  "    var ul=L.match(/^\\s*[-*]\\s+(.*)$/);\n"
                  "    if(ul){tokens.push({t:'li',kind:'ul',text:inline(ul[1])});continue}\n"
                  "    var ol=L.match(/^\\s*(\\d+)\\.\\s+(.*)$/);\n"
                  "    if(ol){tokens.push({t:'li',kind:'ol',text:inline(ol[2])});continue}\n"
                  "    var bq=L.match(/^>\\s?(.*)$/);\n"
                  "    if(bq){tokens.push({t:'bq',text:inline(bq[1])});continue}\n"
                  "    if(L.trim()===''){tokens.push({t:'blank'});continue}\n"
                  "    tokens.push({t:'p',text:inline(L)});\n"
                  "  }\n"
                  "  if(inCode){tokens.push({t:'code',lang:codeLang,text:codeLines.join('\\n')})}\n"

                  ;; Pass 2: group sections into cards, render HTML
                  "  var out=[],j=0,curCard=null;\n"
                  "  function openCard(type){\n"
                  "    if(curCard)out.push('</div></details>');\n"
                  "    curCard=type;\n"
                  "    out.push('<details class=\"http-card '+type+'\">');\n"
                  "    out.push('<summary class=\"card-hdr\"><span class=\"card-icon\">'+(cardIcon[type]||'')+'</span>'+cardTitle[type]+'<span class=\"card-chevron\">›</span></summary>');\n"
                  "    out.push('<div class=\"card-body\">');\n"
                  "  }\n"
                  "  function closeCard(){if(curCard){out.push('</div></details>');curCard=null}}\n"

                  "  var curList=null;\n"
                  "  function closeList(){if(curList){out.push('</'+curList+'>');curList=null}}\n"
                  "  while(j<tokens.length){\n"
                  "    var tk=tokens[j];\n"
                  "    if(tk.t==='http-title'){\n"
                  "      closeList();closeCard();\n"
                  "      out.push('<div class=\"http-title\">');\n"
                  "      out.push('<span class=\"http-method '+tk.d.method.toLowerCase()+'\">'+tk.d.method+'</span>');\n"
                  "      out.push('<span class=\"http-url\">'+esc(tk.d.url)+'</span>');\n"
                  "      out.push('<span class=\"http-status '+statusCls(tk.d.status)+'\">'+tk.d.status+' '+esc(tk.d.statusText)+'</span>');\n"
                  "      out.push('</div>');\n"
                  "    }else if(tk.t==='section'){\n"
                  "      closeList();\n"
                  "      var st=tk.sec.type;\n"
                  "      if(curCard!==st){closeCard();openCard(st)}\n"
                  "      out.push('<div class=\"http-section\">');\n"
                  "      out.push('<div class=\"section-hdr\">'+esc(tk.sec.label)+'</div>');\n"
                  ;; Collect content tokens until next section/title/hr/end
                  "      j++;\n"
                  "      while(j<tokens.length&&tokens[j].t!=='section'&&tokens[j].t!=='http-title'&&tokens[j].t!=='hr'){\n"
                  "        var ct=tokens[j];\n"
                  "        if(ct.t==='code')out.push(codeBlock(ct.lang,ct.text));\n"
                  "        else if(ct.t==='p')out.push('<p>'+ct.text+'</p>');\n"
                  "        else if(/^h[1-6]$/.test(ct.t))out.push('<'+ct.t+'>'+esc(ct.text)+'</'+ct.t+'>');\n"
                  "        j++;\n"
                  "      }\n"
                  "      out.push('</div>');\n"
                  "      continue;\n"
                  "    }else if(tk.t==='code'){closeList();closeCard();out.push(codeBlock(tk.lang,tk.text))}\n"
                  "    else if(tk.t==='hr'){closeList();closeCard();out.push('<hr>')}\n"
                  "    else if(/^h[1-6]$/.test(tk.t)){closeList();closeCard();out.push('<'+tk.t+'>'+esc(tk.text)+'</'+tk.t+'>')}\n"
                  "    else if(tk.t==='li'){\n"
                  "      if(curList!==tk.kind){closeList();curList=tk.kind;out.push('<'+curList+'>')}\n"
                  "      out.push('<li>'+tk.text+'</li>');\n"
                  "    }\n"
                  "    else if(tk.t==='bq'){closeList();out.push('<blockquote>'+tk.text+'</blockquote>')}\n"
                  "    else if(tk.t==='blank'){closeList()}\n"
                  "    else if(tk.t==='p'){closeList();out.push('<p>'+tk.text+'</p>')}\n"
                  "    j++;\n"
                  "  }\n"
                  "  closeList();closeCard();\n"
                  "  return out.join('\\n');\n"
                  "}\n"

                  ;; Copy button handler (global)
                  "window.spelCopy=function(btn){\n"
                  "  var code=btn.parentElement.querySelector('code');\n"
                  "  if(!code)return;\n"
                  "  navigator.clipboard.writeText(code.textContent).then(function(){\n"
                  "    btn.textContent='Copied!';\n"
                  "    btn.classList.add('copied');\n"
                  "    setTimeout(function(){btn.textContent='Copy';btn.classList.remove('copied')},1500);\n"
                  "  });\n"
                  "};\n"

                  ;; Step badge patterns: [API], [UI], [UI+API]
                  "var badgeMap={"
                  "'[UI+API] ':{cls:'ui-api',label:'UI+API'},"
                  "'[API] ':{cls:'api',label:'API'},"
                  "'[UI] ':{cls:'ui',label:'UI'}"
                  "};\n"

                  ;; Replace [TAG] prefix in step name text nodes with styled badge
                  "function renderBadges(){\n"
                  "  document.querySelectorAll('[data-testid=\"test-result-step-title\"]').forEach(function(el){\n"
                  "    if(el.dataset.spelBadge)return;\n"
                  "    var txt=el.textContent;\n"
                  "    for(var prefix in badgeMap){\n"
                  "      if(txt.indexOf(prefix)===0){\n"
                  "        el.dataset.spelBadge='1';\n"
                  "        var b=badgeMap[prefix];\n"
                  "        var span=document.createElement('span');\n"
                  "        span.className='spel-badge '+b.cls;\n"
                  "        span.textContent=b.label;\n"
                  ;; Walk text nodes to find and replace the prefix
                  "        var walker=document.createTreeWalker(el,NodeFilter.SHOW_TEXT);\n"
                  "        while(walker.nextNode()){\n"
                  "          var n=walker.currentNode;\n"
                  "          var idx=n.textContent.indexOf(prefix);\n"
                  "          if(idx>=0){\n"
                  "            var after=n.splitText(idx);\n"
                  "            after.textContent=after.textContent.slice(prefix.length);\n"
                  "            n.parentNode.insertBefore(span,after);\n"
                  "            break;\n"
                  "          }\n"
                  "        }\n"
                  "        break;\n"
                  "      }\n"
                  "    }\n"
                  "  });\n"
                  "}\n"

                  ;; MutationObserver target function — markdown + badges
                  "function renderMd(){\n"
                  "  document.querySelectorAll('pre[data-testid=\"code-attachment-content\"].language-md').forEach(function(pre){\n"
                  "    if(pre.dataset.spelRendered)return;\n"
                  "    if(document.readyState==='loading'&&!pre.nextSibling)return;\n"
                  "    pre.dataset.spelRendered='1';\n"
                  "    var code=pre.querySelector('code');\n"
                  "    if(!code)return;\n"
                  "    var div=document.createElement('div');\n"
                  "    div.className='spel-md';\n"
                  "    div.innerHTML=spelMd(code.textContent);\n"
                  "    pre.replaceWith(div);\n"
                  "  });\n"
                  "}\n"

                  ;; Render completed attachments while the document streams in.
                  "var obs=new MutationObserver(function(){renderMd();renderBadges()});\n"
                  "obs.observe(document.documentElement,{childList:true,subtree:true});\n"
                  "document.addEventListener('DOMContentLoaded',function(){renderMd();renderBadges()});\n"
                  "renderMd();renderBadges();\n"
                  "}());\n"
                  "</script>\n")

                patched (-> content
                          (str/replace "</head>" (str css js "</head>")))]
            (when (not= content patched)
              (spit idx patched))))))))

;; ---------------------------------------------------------------------------
;; Allure CLI resolution
;; ---------------------------------------------------------------------------

(def ^:private allure-version
  "Pinned Allure CLI version — this library owns the versioning."
  "3.3.1")

(def ^:private allure-npm-pkg
  (str "allure@" allure-version))

(defn- cmd-exists?
  "Returns true when `cmd` is found on PATH."
  [^String cmd]
  (try
    (let [pb (doto (ProcessBuilder. ^"[Ljava.lang.String;" (into-array String ["which" cmd]))
               (.redirectErrorStream true))
          proc (.start pb)
          exit (.waitFor proc)]
      (zero? exit))
    (catch Exception _ false)))

(defn- run-proc!
  "Run a command with inherited IO and return the exit code.
   When SPEL_ALLURE_CWD is set, uses it as the working directory for the process.
   Useful on read-only filesystems (e.g. AWS Lambda) where allure plugins
   try to write to CWD."
  [cmd]
  (let [pb (doto (driver/node-process-builder (vec cmd)) (.inheritIO))]
    (when-let [cwd (or (System/getProperty "spel.allure.cwd")
                     (System/getenv "SPEL_ALLURE_CWD"))]
      (.directory pb (java.io.File. cwd)))
    (let [proc (.start pb)]
      (.waitFor proc))))

(defn- resolve-allure-cmd!
  "Determine how to invoke the Allure CLI.  Tries in order:
     1. Global `allure` binary   (preferred — no npx overhead, works on read-only FS)
     2. npx with pinned version  (fallback — reproducible version)
     3. Install via npm globally (last resort)
   Returns a vector of command parts, or nil when unavailable."
  []
  (cond
    ;; 1. Global allure on PATH — fast, no npx cache writes (works on read-only FS)
    (cmd-exists? "allure")
    (do (println "  Using globally installed allure")
        ["allure"])

    ;; 2. npx available → use the pinned version
    (cmd-exists? "npx")
    (do (println (str "  Using npx " allure-npm-pkg))
        ["npx" "--yes" allure-npm-pkg])

    ;; 3. npm available → install globally, then use allure
    (cmd-exists? "npm")
    (do (println (str "  Neither allure nor npx found. Installing " allure-npm-pkg " globally..."))
        (if (zero? (long (run-proc! ["npm" "install" "-g" allure-npm-pkg])))
          (do (println (str "  Installed " allure-npm-pkg " successfully."))
              ["allure"])
          (do (println "  x npm install failed - cannot generate report.")
              nil)))

    ;; 4. Nothing available
    :else
    (do (println "  x Cannot generate report: allure, npx, and npm are all missing.")
        (println (str "    Install Node.js (https://nodejs.org) or: npm i -g " allure-npm-pkg))
        nil)))

;; ---------------------------------------------------------------------------
;; Report generation
;; ---------------------------------------------------------------------------

(def ^:private history-file ".allure-history.jsonl")

(defn- history-limit
  ^String []
  (or (System/getProperty "lazytest.allure.history-limit")
    (System/getenv "LAZYTEST_ALLURE_HISTORY_LIMIT")
    "10"))

(defn- report-name
  ^String []
  (or (System/getProperty "lazytest.allure.report-name")
    (System/getenv "LAZYTEST_ALLURE_REPORT_NAME")
    (when-let [v (project-version)]
      (str "spel v" v))))

(defn- report-logo
  ^String []
  (let [path (or (System/getProperty "lazytest.allure.logo")
               (System/getenv "LAZYTEST_ALLURE_LOGO"))]
    (when (and path (.isFile (io/file path)))
      path)))

;; ---------------------------------------------------------------------------
;; Badge SVG Generation
;; ---------------------------------------------------------------------------

(defn- text-width
  "Approximate text width for badge label/message (based on typical font metrics)."
  ^long [^String text]
  (long (* (count text) 6.5)))

(defn generate-badge-svg
  "Generate a shields.io-style SVG badge.
   Returns the SVG string.
   
   Options:
     :label   - left side text (default: \"tests\")
     :message - right side text (e.g. \"42 passed\")
     :color   - right side color (default: \"brightgreen\")
     :style   - badge style: :flat (default), :flat-square, :for-the-badge"
  [{:keys [label message color style]
    :or {label "tests" message "0 passed" color "brightgreen" style :flat}}]
  (let [color-map {"brightgreen" "#4c1"
                   "green" "#97ca00"
                   "yellow" "#dfb317"
                   "orange" "#fe7d37"
                   "red" "#e05d44"
                   "blue" "#007ec6"
                   "lightgrey" "#9f9f9f"
                   "gray" "#555"}
        bg-color (get color-map (name color) (name color))
        label-width (+ (text-width label) 10)
        message-width (+ (text-width message) 10)
        total-width (+ label-width message-width)
        label-x (quot label-width 2)
        message-x (+ label-width (quot message-width 2))
        radius (if (= style :flat-square) 0 3)]
    (str
      "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
      "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"" total-width "\" height=\"20\" role=\"img\" aria-label=\"" label ": " message "\">\n"
      "  <title>" label ": " message "</title>\n"
      "  <linearGradient id=\"s\" x2=\"0\" y2=\"100%\">\n"
      "    <stop offset=\"0\" stop-color=\"#bbb\" stop-opacity=\".1\"/>\n"
      "    <stop offset=\"1\" stop-opacity=\".1\"/>\n"
      "  </linearGradient>\n"
      "  <clipPath id=\"r\">\n"
      "    <rect width=\"" total-width "\" height=\"20\" rx=\"" radius "\" fill=\"#fff\"/>\n"
      "  </clipPath>\n"
      "  <g clip-path=\"url(#r)\">\n"
      "    <rect width=\"" label-width "\" height=\"20\" fill=\"#555\"/>\n"
      "    <rect x=\"" label-width "\" width=\"" message-width "\" height=\"20\" fill=\"" bg-color "\"/>\n"
      "    <rect width=\"" total-width "\" height=\"20\" fill=\"url(#s)\"/>\n"
      "  </g>\n"
      "  <g fill=\"#fff\" text-anchor=\"middle\" font-family=\"Verdana,Geneva,DejaVu Sans,sans-serif\" text-rendering=\"geometricPrecision\" font-size=\"11\">\n"
      "    <text x=\"" label-x "\" y=\"14\" fill=\"#010101\" fill-opacity=\".3\">" label "</text>\n"
      "    <text x=\"" label-x "\" y=\"13\" fill=\"#fff\">" label "</text>\n"
      "    <text x=\"" message-x "\" y=\"14\" fill=\"#010101\" fill-opacity=\".3\">" message "</text>\n"
      "    <text x=\"" message-x "\" y=\"13\" fill=\"#fff\">" message "</text>\n"
      "  </g>\n"
      "</svg>")))

(defn count-test-results
  "Count test results from allure-results directory.
   Returns map with :passed, :failed, :broken, :skipped, :total."
  [^String results-dir]
  (let [dir (io/file results-dir)
        result-files (when (.isDirectory dir)
                       (filter #(str/ends-with? (.getName ^File %) "-result.json")
                         (.listFiles dir)))
        statuses (for [^File f result-files
                       :let [content (slurp f)
                             ;; Simple regex extraction - avoids JSON parsing dependency
                             status (second (re-find #"\"status\"\s*:\s*\"(\w+)\"" content))]
                       :when status]
                   status)
        counts (frequencies statuses)]
    {:passed (long (get counts "passed" 0))
     :failed (long (get counts "failed" 0))
     :broken (long (get counts "broken" 0))
     :skipped (long (get counts "skipped" 0))
     :total (count statuses)}))

(defn generate-badge-file!
  "Generate badge.svg file in the given directory based on test results.
   Returns the badge message string."
  [^String results-dir ^String output-dir]
  (let [{:keys [^long passed ^long failed ^long broken]} (count-test-results results-dir)
        failures (+ failed broken)
        message (if (pos? failures)
                  (str passed " passed, " failures " failed")
                  (str passed " passed"))
        color (if (pos? failures) "red" "brightgreen")
        svg (generate-badge-svg {:label "Allure Report"
                                 :message message
                                 :color color})
        badge-file (io/file output-dir "badge.svg")]
    (spit badge-file svg)
    (println (str "  Generated badge.svg: " message))
    message))

(defn- delete-tree!
  "Recursively delete `f` (file or directory). Forces writability so read-only
  allure outputs delete cleanly, and recurses before unlinking so non-empty
  directories are removed too. Returns true when `f` no longer exists afterwards."
  [^java.io.File f]
  (when (.exists f)
    (when (.isDirectory f)
      (doseq [^java.io.File child (or (seq (.listFiles f)) [])]
        (delete-tree! child)))
    (try (.setWritable f true true) (catch Exception _))
    (.delete f))
  (not (.exists f)))

(defn generate-html-report!
  "Resolve the Allure CLI, run `allure awesome` (with history when
   available), optionally embed the local trace viewer, and patch the
   report JS.  Returns true on success."
  [^String results-dir ^String report-dir-path]
  (println "Generating Allure HTML report...")
  (flush)
  (let [report (io/file report-dir-path)]
    (if-let [allure-cmd (resolve-allure-cmd!)]
      (do
        ;; Remove old report
        (when (.exists report)
          (doseq [^File f (reverse (file-seq report))]
            (.delete f)))
        ;; Build command — use `allure awesome` which supports --history-path
        (let [history (io/file history-file)
              cmd     (cond-> (into allure-cmd ["awesome" results-dir
                                                "-o" report-dir-path])
                        (.isFile history)
                        (into ["-h" (.getAbsolutePath history)])
                        (report-name)
                        (into ["--name" (report-name)])
                        (report-logo)
                        (into ["--logo" (report-logo)]))
              exit    (long (run-proc! cmd))]
          (if (zero? exit)
            (do
              ;; Remove the awesome/ sub-report — allure "awesome" emits BOTH a
              ;; root report AND an embedded awesome/ copy carrying byte-identical
              ;; attachments (~2x report size). The root index.html never links
              ;; into awesome/, so dropping it is safe.
              (let [awesome (io/file report "awesome")]
                (when (.exists awesome)
                  (delete-tree! awesome)
                  (println "  Removed awesome/ sub-report (dedupes attachments)")))
              ;; Embed trace viewer from classpath resources
              (when (copy-trace-viewer! (io/file report "trace-viewer"))
                (patch-trace-viewer-url! report)
                (inject-trace-viewer-prewarm! report)
                (patch-sw-safari-compat! report)
                (patch-sw-safari-transform-stream! report)
                (patch-sw-safari-response-headers! report))
              ;; Inject video player modal
              (inject-video-modal! report)
              ;; Inject inline markdown renderer for text/markdown attachments
              (inject-markdown-renderer! report)
              (when-let [logo (report-logo)]
                (let [src (io/file logo)
                      dst (io/file report (.getName src))]
                  (io/copy src dst)))
              ;; Generate badge.svg in report directory
              (generate-badge-file! results-dir report-dir-path)
              (run-proc! (into allure-cmd ["history" results-dir
                                           "-h" history-file
                                           "--history-limit" (history-limit)]))
              ;; allure history (3.3.1+) can recreate the awesome/ sub-report while
              ;; writing trend history — re-check right before handing the report off,
              ;; so the deployed site never ships the duplicated attachments.
              (let [awesome (io/file report "awesome")]
                (when (.exists awesome)
                  (delete-tree! awesome)
                  (println "  Removed late-recreated awesome/ sub-report")))
              (println (str "  Report ready at " report-dir-path "/"))
              true)
            (do
              (println (str "  x allure generate failed (exit " exit ")"))
              false))))
      false)))

;; =============================================================================
;; Merge Results
;; =============================================================================

(defn- report-renderer
  "Which report renderer to use: :allure (npm) or :alternative (native Clojure).
   Defaults to :allure for backward compatibility.
   The legacy value `block` is still accepted as an alias for `alternative`."
  []
  (let [raw (or (System/getProperty "lazytest.allure.report-renderer")
              (System/getenv "LAZYTEST_ALLURE_REPORT_RENDERER")
              "allure")]
    (case raw
      "block" :alternative
      (keyword raw))))

(defn- merge-environment-properties
  "Merge multiple environment.properties files. Later values win for
   duplicate keys."
  [^File output-dir source-dirs]
  (let [props (into {}
                (for [^File dir source-dirs
                      :let [f (io/file dir "environment.properties")]
                      :when (.isFile f)
                      line (str/split-lines (slurp f))
                      :when (not (str/blank? line))
                      :let [[k v] (str/split line #"\s*=\s*" 2)]
                      :when k]
                  [k (or v "")]))]
    (when (seq props)
      (let [content (->> props
                      (sort-by key)
                      (map (fn [[k v]] (str k " = " v)))
                      (str/join "\n"))]
        (spit (io/file output-dir "environment.properties") (str content "\n"))))))

(defn- merge-categories-json
  "Merge multiple categories.json files. Deduplicates by :name."
  [^File output-dir source-dirs]
  (let [all-cats (for [^File dir source-dirs
                       :let [f (io/file dir "categories.json")]
                       :when (.isFile f)
                       :let [content (str/trim (slurp f))]
                       :when (not (str/blank? content))
                       ;; Parse JSON array manually — each entry has "name" key
                       :let [entries (re-seq #"\{[^}]+\}" content)]
                       entry entries]
                   entry)
        ;; Deduplicate by extracting name from JSON string
        unique (vals (into {}
                       (for [entry all-cats
                             :let [name-match (re-find #"\"name\"\s*:\s*\"([^\"]+)\"" entry)]
                             :when name-match]
                         [(second name-match) entry])))]
    (when (seq unique)
      (spit (io/file output-dir "categories.json")
        (str "[\n  " (str/join ",\n  " unique) "\n]\n")))))

(defn merge-results!
  "Merge N allure-results directories into one output directory.

   Copies all result JSON files, attachment files, and supplementary
   files (environment.properties, categories.json) from each source dir
   into the output dir. UUID-prefixed files are copied directly (no
   collision risk). Supplementary files are merged intelligently:
   environment.properties uses last-wins per key, categories.json is
   deduplicated by name.

   Options:
     :output-dir  - target directory (default: \"allure-results\")
     :clean       - whether to clean output dir first (default: true)
     :report      - whether to generate HTML report after merge (default: true)
     :report-dir  - HTML report output dir (default: \"allure-report\")
     :renderer    - :allure (default) or :alternative

   Returns map with :merged count and :output-dir path."
  [source-dirs {:keys [output-dir clean report report-dir renderer]
                :or   {output-dir "allure-results"
                       clean      true
                       report     true
                       report-dir "allure-report"
                       renderer   nil}}]
  (let [out     (io/file output-dir)
        sources (mapv io/file source-dirs)
        valid   (filterv #(.isDirectory ^File %) sources)]
    (when (empty? valid)
      (println "Error: no valid source directories found")
      (println (str "  Checked: " (str/join ", " source-dirs)))
      (System/exit 1))
    ;; Clean output if requested
    (when clean
      (when (.exists out)
        (doseq [^File f (reverse (file-seq out))]
          (.delete f))))
    (.mkdirs out)
    ;; Copy UUID-prefixed files (results + attachments)
    (let [copied (atom 0)]
      (doseq [^File dir valid
              ^File f (.listFiles dir)
              :when (.isFile f)
              :let [name (.getName f)]
              :when (and (not= name "environment.properties")
                      (not= name "categories.json"))]
        (io/copy f (io/file out name))
        (swap! copied inc))
      ;; Merge supplementary files
      (merge-environment-properties out valid)
      (merge-categories-json out valid)
      (let [result-count (count (filter #(str/ends-with? (.getName ^File %) "-result.json")
                                  (.listFiles out)))]
        (println (str "Merged " @copied " files from " (count valid) " directories into " output-dir "/"))
        (println (str "  " result-count " test results"))
        ;; Generate HTML report if requested
        (when report
          (let [effective-renderer (or renderer (report-renderer))]
            (if (= :alternative effective-renderer)
              (alternative-report/generate! output-dir report-dir
                {:title (or (report-name) "Test Report")})
              (generate-html-report! output-dir report-dir))))
        {:merged @copied
         :results result-count
         :output-dir output-dir}))))

;; =============================================================================
;; Reporter
;; =============================================================================

(defn output-dir
  "Determine the output directory. Checks system property, then env var,
   then falls back to allure-results."
  ^String []
  (or (System/getProperty "lazytest.allure.output")
    (System/getenv "LAZYTEST_ALLURE_OUTPUT")
    "allure-results"))

(defn- generate-report?
  "Whether to generate HTML report after tests.
   Defaults to true. Set to false when multiple suites share one output dir
   and the report is generated once at the end."
  []
  (Boolean/parseBoolean
    (or (System/getProperty "lazytest.allure.generate-report")
      (System/getenv "LAZYTEST_ALLURE_GENERATE_REPORT")
      "true")))

(defn- clean?
  "Whether to clean the output dir before writing results.
   Defaults to true. Set to false when appending results from a prior suite."
  []
  (Boolean/parseBoolean
    (or (System/getProperty "lazytest.allure.clean")
      (System/getenv "LAZYTEST_ALLURE_CLEAN")
      "true")))

(defn- clean-output-dir!
  "Remove old results and recreate the output directory.
   History is managed externally via `.allure-history.jsonl` (Allure 3
   JSONL mechanism), so nothing inside the results dir needs preserving."
  [^File dir]
  (when (.exists dir)
    (doseq [^File f (reverse (file-seq dir))]
      (.delete f)))
  (.mkdirs dir))

(defmulti allure
  "Allure 3 reporter multimethod for Lazytest.

   Writes JSON results and auto-generates HTML report with embedded trace viewer.

   Usage:
     --output nested --output com.blockether.spel.allure-reporter/allure"
  {:arglists '([config m])}
  #'reporter-dispatch)

(defmethod allure :default [_ _])

(defmethod allure :begin-test-run [_ _]
  (let [dir (io/file (output-dir))]
    (if (clean?)
      (clean-output-dir! dir)
      (.mkdirs dir))
    (reset! run-state {:hostname (hostname)
                       :start-ms (System/currentTimeMillis)
                       :output-dir dir})
    (allure/set-reporter-active! true)
    (install-output-capture!)))

(defmethod allure :end-test-run [_ m]
  (allure/set-reporter-active! false)
  (uninstall-output-capture!)
  (let [results    (:results m)
        dir        (:output-dir @run-state)
        ns-suites  (when (s/suite-result? results)
                     (filter ns-suite? (:children results)))
        all-cases  (mapcat #(collect-test-cases % [] nil) ns-suites)
        n          (count all-cases)]
    ;; Write individual result files
    (doseq [tc all-cases]
      (let [result (build-result tc dir)
            filename (str (:uuid result) "-result.json")]
        (spit (io/file dir filename) (->json-pretty result))))
    ;; Write supplementary files
    (write-environment-properties! dir)
    (write-categories-json! dir)
    (println (str "\nAllure results written to " (output-dir) "/ (" n " test cases)"))
    (when (generate-report?)
      (if (= :alternative (report-renderer))
        (alternative-report/generate! (output-dir) (report-dir)
          {:title (or (report-name) "Test Report")})
        (generate-html-report! (output-dir) (report-dir))))))

;; =============================================================================
;; clojure.test Reporter (merged from allure-ct-reporter)
;; =============================================================================

;; Configuration

(defn ct-enabled?
  "Check if the clojure.test Allure reporter is enabled."
  []
  (Boolean/parseBoolean
    (or (System/getProperty "allure.clojure-test.enabled")
      (System/getenv "ALLURE_CLOJURE_TEST_ENABLED")
      "false")))

(defn- ct-output-dir-path
  ^String []
  (or (System/getProperty "allure.clojure-test.output")
    (System/getenv "ALLURE_CLOJURE_TEST_OUTPUT")
    "allure-results"))

(defn- ct-report?
  "Whether to generate HTML report on summary."
  []
  (Boolean/parseBoolean
    (or (System/getProperty "allure.clojure-test.report")
      (System/getenv "ALLURE_CLOJURE_TEST_REPORT")
      "true")))

(defn- ct-clean?
  "Whether to clean output dir on start."
  []
  (Boolean/parseBoolean
    (or (System/getProperty "allure.clojure-test.clean")
      (System/getenv "ALLURE_CLOJURE_TEST_CLEAN")
      "true")))

(defn- ct-report-dir
  "Report output directory for clojure.test runs."
  ^String []
  (or (System/getProperty "allure.clojure-test.report-dir")
    (System/getenv "ALLURE_CLOJURE_TEST_REPORT_DIR")
    "allure-report"))

;; State

(def ^:private ct-run-state
  "Mutable state for the current test run. nil when not active."
  (atom nil))

(def ^:private ct-test-state
  "Mutable state for the current test var. nil between tests."
  (atom nil))

(def ^:private ct-counters
  (atom {:test 0 :pass 0 :fail 0 :error 0}))

(def ^:private ct-fixture-originals
  "Original :each fixtures per namespace, for restoration on :end-test-ns."
  (atom {}))

(def ^:private ct-pending-results
  "Buffered test results. Written to disk at finalize with corrected parentSuite."
  (atom []))

;; Unique helpers

(defn- common-segment-prefix
  "Longest common dot-separated prefix of a collection of package strings.
   E.g. [\"com.blockether.spel\" \"com.blockether.spel.ct\"] => \"com.blockether.spel\""
  ^String [packages]
  (let [packages (vec (distinct (remove str/blank? packages)))]
    (when (seq packages)
      (if (= 1 (count packages))
        (first packages)
        (let [segments (mapv #(str/split % #"\\.") packages)
              min-len  (long (apply min (map count segments)))]
          (loop [i (long 0) acc []]
            (if (>= i min-len)
              (when (seq acc) (str/join "." acc))
              (let [seg (nth (first segments) i)]
                (if (every? #(= seg (nth % i)) (rest segments))
                  (recur (inc i) (conj acc seg))
                  (when (seq acc) (str/join "." acc)))))))))))

(defn- scan-existing-packages
  "Extract package label values from existing result JSONs in output dir.
   Used to compute common parent prefix across multiple test runs."
  [^File output-dir]
  (when (.exists output-dir)
    (->> (.listFiles output-dir)
      (filter #(str/ends-with? (.getName ^File %) "-result.json"))
      (keep (fn [^File f]
              (try
                (let [content (slurp f)]
                  (second (re-find #"\"name\"\s*:\s*\"package\"\s*,\s*\n\s*\"value\"\s*:\s*\"([^\"]+)\"" content)))
                (catch Exception _ nil))))
      distinct
      vec)))

(defn- testing-context-str []
  (when (seq ct/*testing-contexts*)
    (str/join " > " (reverse ct/*testing-contexts*))))

(defn- common-testing-context
  "Extract common testing context prefix from a test's assertions.
   Returns the longest \" > \"-delimited prefix shared by all assertions
   that have a testing context, or the single context when only one exists.
   Returns nil when no assertions carry a testing context."
  [assertions]
  (let [contexts (->> assertions
                   (keep :context)
                   (remove str/blank?)
                   distinct
                   vec)]
    (when (seq contexts)
      (if (= 1 (count contexts))
        (first contexts)
        (let [parts   (mapv #(str/split % #" > ") contexts)
              min-len (long (apply min (map count parts)))]
          (loop [i (long 0) acc []]
            (if (>= i min-len)
              (when (seq acc) (str/join " > " acc))
              (let [seg (nth (first parts) i)]
                (if (every? #(= seg (nth % i)) (rest parts))
                  (recur (inc i) (conj acc seg))
                  (when (seq acc) (str/join " > " acc)))))))))))

(defn- ct-build-labels
  [ts sub-suite]
  (let [ns-name  (:ns-name ts)
        pkg      (when ns-name (ns-package ns-name))
        hn       (:hostname @ct-run-state)]
    (cond-> []
      ns-name   (conj {:name "suite" :value ns-name})
      pkg       (conj {:name "parentSuite" :value pkg})
      sub-suite (conj {:name "subSuite" :value sub-suite})
      hn        (conj {:name "host" :value hn})
      true      (conj {:name "thread" :value "main"})
      true      (conj {:name "language" :value "clojure"})
      true      (conj {:name "framework" :value "clojure.test"})
      true      (conj {:name "tag" :value "clojure-test"})
      pkg       (conj {:name "package" :value pkg})
      ns-name   (conj {:name "testClass" :value ns-name})
      true      (conj {:name "testMethod" :value (:test-name ts)}))))

(defn- ct-build-display-name
  "Build a human-readable test name including testing context.
   Mirrors the Lazytest reporter's \"path > name\" convention."
  ^String [ts common-ctx]
  (if common-ctx
    (str common-ctx " > " (:test-name ts))
    (:test-name ts)))

(defn- build-steps-from-assertions
  [assertions start-ms stop-ms]
  (mapv (fn [a]
          (let [ctx    (:context a)
                name   (cond
                         (and ctx (:message a))
                         (str ctx " > " (:message a))

                         ctx
                         (str ctx " > " (pr-str (:expected a)))

                         (:message a)
                         (:message a)

                         :else
                         (pr-str (:expected a)))
                status (case (:type a)
                         :pass  "passed"
                         :fail  "failed"
                         :error "broken")]
            (cond-> {:name         name
                     :status       status
                     :start        start-ms
                     :stop         stop-ms
                     :steps        []
                     :attachments  []
                     :parameters   (cond-> []
                                     (:expected a)
                                     (conj {:name "expected"
                                            :value (pr-str (:expected a))})
                                     (some? (:actual a))
                                     (conj {:name "actual"
                                            :value (pr-str (:actual a))}))}
              (= :fail (:type a))
              (assoc :statusDetails
                {:message (or (:message a)
                            "Assertion failed")}))))
    assertions))

(defn- ct-build-status-details
  [ts]
  (when-let [failure (:first-failure ts)]
    (let [^Throwable actual-t (when (instance? Throwable (:actual failure))
                                (:actual failure))
          msg (or (:message failure)
                (when actual-t (.getMessage actual-t))
                "Test failed")
          expected (when (:expected failure) (pr-str (:expected failure)))
          actual   (when (some? (:actual failure)) (pr-str (:actual failure)))
          trace    (stacktrace-str actual-t)]
      (cond-> {:message (str msg
                          (when expected
                            (str "\nExpected: " expected
                              "\nActual: " actual)))}
        trace (assoc :trace trace)))))

(defn- ct-write-test-result!
  [ts]
  (let [dir         (:output-dir @ct-run-state)
        result-uuid (uuid)
        full-name   (:full-name ts)
        stop-ms     (System/currentTimeMillis)
        start-ms    (:start-ms ts)
        status      (case (:status ts)
                      :pass  "passed"
                      :fail  "failed"
                      :error "broken")
        ;; Derive testing context for subSuite and display name
        common-ctx  (common-testing-context (:assertions ts))
        sub-suite   (when common-ctx
                      (first (str/split common-ctx #" > ")))
        ctx         (:allure-context ts)
        ctx-labels  (when ctx (:labels ctx))
        ctx-links   (when ctx (:links ctx))
        ctx-params  (when ctx (:parameters ctx))
        ctx-atts    (when ctx (:attachments ctx))
        ctx-desc    (when ctx (:description ctx))
        ctx-steps   (when ctx (vec (:steps ctx)))
        steps       (if (explicit-allure-steps? ctx-steps)
                      (strip-step-stack ctx-steps)
                      (into (build-steps-from-assertions (:assertions ts) start-ms stop-ms)
                        (strip-step-stack (vec ctx-steps))))
        out-att     (write-attachment! dir (:system-out ts) "Full stdout log")
        err-att     (write-attachment! dir (:system-err ts) "Full stderr log")
        trace-att   (when-let [tp (:allure/trace-path ts)]
                      (copy-file-attachment! dir tp "Playwright Trace"
                        "application/vnd.allure.playwright-trace" ".zip"))
        har-att     (when-let [hp (:allure/har-path ts)]
                      (copy-file-attachment! dir hp "Network Activity (HAR)"
                        "application/json" ".har"))
        video-att   (when-let [vp (:allure/video-path ts)]
                      (copy-file-attachment! dir vp "Video Recording"
                        "video/webm" ".webm"))
        io-atts     (filterv some? [out-att err-att trace-att har-att video-att])
        all-labels  (into (ct-build-labels ts sub-suite) ctx-labels)
        all-links   (or (seq ctx-links) [])
        all-params  (or (seq ctx-params) [])
        all-atts    (into (vec io-atts) ctx-atts)
        status-det  (ct-build-status-details ts)
        result      (cond-> {:uuid        result-uuid
                             :historyId   (md5-hex full-name)
                             :testCaseId  (md5-hex full-name)
                             :fullName    full-name
                             :name        (ct-build-display-name ts common-ctx)
                             :status      status
                             :stage       "finished"
                             :start       start-ms
                             :stop        stop-ms
                             :labels      all-labels
                             :parameters  all-params
                             :links       all-links}
                      status-det     (assoc :statusDetails status-det)
                      (seq all-atts) (assoc :attachments all-atts)
                      (seq steps)    (assoc :steps steps)
                      ctx-desc       (assoc :description ctx-desc))]
    (swap! ct-pending-results conj result)))

;; Lifecycle

(defn- ensure-ct-run-started!
  "Lazy-init on first :begin-test-ns. Creates output dir, resets state."
  []
  (when-not @ct-run-state
    (let [dir-path (ct-output-dir-path)
          dir      (io/file dir-path)]
      (when (ct-clean?)
        (when (.exists dir)
          (doseq [^File f (reverse (file-seq dir))]
            (.delete f))))
      (.mkdirs dir)
      (reset! ct-run-state {:hostname        (hostname)
                            :start-ms        (System/currentTimeMillis)
                            :output-dir      dir
                            :output-dir-path dir-path})
      (reset! ct-counters {:test 0 :pass 0 :fail 0 :error 0})
      (reset! ct-fixture-originals {})
      (reset! ct-pending-results [])
      (allure/set-reporter-active! true))))

(defn- flush-ct-pending-results!
  "Compute common parent namespace from all packages (existing + current run),
   update parentSuite labels, and write all buffered results to disk."
  []
  (let [dir      (:output-dir @ct-run-state)
        results  @ct-pending-results
        ;; Collect packages from this run's results
        current-pkgs (->> results
                       (mapcat :labels)
                       (filter #(= "package" (:name %)))
                       (map :value))
        ;; Also scan existing results from prior runs (e.g. lazytest)
        existing-pkgs (scan-existing-packages dir)
        all-pkgs      (into (vec existing-pkgs) current-pkgs)
        common-parent (common-segment-prefix all-pkgs)]
    (doseq [result results]
      (let [updated (if common-parent
                      (update result :labels
                        (fn [labels]
                          (mapv (fn [l]
                                  (if (= "parentSuite" (:name l))
                                    (assoc l :value common-parent)
                                    l))
                            labels)))
                      result)]
        (spit (io/file dir (str (:uuid updated) "-result.json"))
          (->json-pretty updated))))
    (reset! ct-pending-results [])))

(defn- finalize-ct-run!
  "Flush buffered results, write supplementary files, optionally generate HTML report."
  []
  (when @ct-run-state
    (allure/set-reporter-active! false)
    (flush-ct-pending-results!)
    (let [dir (:output-dir @ct-run-state)]
      (write-environment-properties! dir)
      (write-categories-json! dir))
    (when (ct-report?)
      (if (= :alternative (report-renderer))
        (alternative-report/generate! (ct-output-dir-path) (ct-report-dir)
          {:title (or (report-name) "Test Report")})
        (generate-html-report! (ct-output-dir-path) (ct-report-dir))))
    (reset! ct-run-state nil)))

;; Allure context fixture

(defn with-allure-context
  "clojure.test :each fixture that binds the Allure in-test API context.

   Enables allure/step, allure/epic, allure/screenshot, etc. within
   clojure.test deftest blocks. Also captures stdout/stderr per test.

   Auto-injected as the OUTERMOST :each fixture by the global reporter
   hooks — test files never reference this directly.

   Being outermost is critical: inner fixtures (e.g. with-traced-page)
   tear down BEFORE this fixture's post-`(f)` code runs, so trace/HAR
   files are fully written by the time we copy them into allure-results."
  [f]
  (if-not @ct-run-state
    (f)
    (let [ctx-atom    (atom (allure/make-context))
          network-log (atom [])
          out-sw      (StringWriter.)
          err-sw      (StringWriter.)]
      (binding [allure/*context*     ctx-atom
                allure/*output-dir*  (:output-dir @ct-run-state)
                allure/*test-title*  (some-> @ct-test-state :test-name)
                allure/*test-out*    out-sw
                allure/*test-err*    err-sw
                allure/*network-log* network-log
                *out*                (PrintWriter. out-sw true)
                *err*                (PrintWriter. err-sw true)]
        (try
          (f)
          (finally
            (allure/flush-network-steps!))))
      ;; After (f): inner fixtures have torn down and network exchanges, trace,
      ;; and HAR files have all been snapshotted into the live context.
      (when-let [ts @ct-test-state]
        (when (:ended? ts)
          (ct-write-test-result! (assoc ts :allure-context @ctx-atom))
          (reset! ct-test-state nil))))))

;; Event handlers

(defn- ct-on-begin-ns [m]
  (let [ns-obj   (:ns m)
        existing (::ct/each-fixtures (meta ns-obj))]
    ;; Save original fixtures for restoration
    (swap! ct-fixture-originals assoc ns-obj existing)
    ;; Auto-inject with-allure-context as outermost :each fixture
    (alter-meta! ns-obj assoc ::ct/each-fixtures
      (into [with-allure-context] (or existing [])))
    (swap! ct-run-state assoc :current-ns (str (ns-name ns-obj)))))

(defn- ct-on-end-ns [m]
  (let [ns-obj   (:ns m)
        original (get @ct-fixture-originals ns-obj)]
    ;; Restore original fixtures
    (if original
      (alter-meta! ns-obj assoc ::ct/each-fixtures original)
      (alter-meta! ns-obj dissoc ::ct/each-fixtures))
    (swap! ct-fixture-originals dissoc ns-obj)
    (swap! ct-run-state dissoc :current-ns)))

(defn- ct-on-begin-var [m]
  (let [v       (:var m)
        ns-name (str (ns-name (:ns (meta v))))
        tname   (str (:name (meta v)))]
    (swap! ct-counters update :test inc)
    (reset! ct-test-state
      {:var           v
       :ns-name       ns-name
       :test-name     tname
       :full-name     (str ns-name "." tname)
       :start-ms      (System/currentTimeMillis)
       :assertions    []
       :status        :pass
       :first-failure nil})))

(defn- ct-on-pass [m]
  (swap! ct-counters update :pass inc)
  (when @ct-test-state
    (swap! ct-test-state update :assertions conj
      {:type     :pass
       :context  (testing-context-str)
       :message  (:message m)
       :expected (:expected m)
       :actual   (:actual m)})))

(defn- ct-on-fail [m]
  (swap! ct-counters update :fail inc)
  (when @ct-test-state
    (swap! ct-test-state
      (fn [s]
        (-> s
          (update :assertions conj
            {:type     :fail
             :context  (testing-context-str)
             :message  (:message m)
             :expected (:expected m)
             :actual   (:actual m)})
          (assoc :status :fail)
          (cond-> (nil? (:first-failure s))
            (assoc :first-failure m)))))))

(defn- ct-on-error [m]
  (swap! ct-counters update :error inc)
  (when @ct-test-state
    (swap! ct-test-state
      (fn [s]
        (-> s
          (update :assertions conj
            {:type     :error
             :context  (testing-context-str)
             :message  (:message m)
             :expected (:expected m)
             :actual   (:actual m)})
          (assoc :status :error)
          (cond-> (nil? (:first-failure s))
            (assoc :first-failure m)))))))

(defn- ct-on-end-var [_m]
  (when-let [ts @ct-test-state]
    (let [ts (cond-> ts
               allure/*context*
               (assoc :allure-context @allure/*context*)

               allure/*trace-path*
               (assoc :allure/trace-path (str allure/*trace-path*))

               allure/*har-path*
               (assoc :allure/har-path (str allure/*har-path*))

               allure/*video-path*
               (assoc :allure/video-path (str allure/*video-path*))

               allure/*test-out*
               (assoc :system-out (str allure/*test-out*))

               allure/*test-err*
               (assoc :system-err (str allure/*test-err*)))]
      (reset! ct-test-state (assoc ts :ended? true))
      ;; When with-allure-context is active, defer writing until after
      ;; inner fixtures tear down (trace files written).
      ;; When NOT active (shouldn't happen, but defensive), write immediately.
      (when-not allure/*context*
        (ct-write-test-result! ts)
        (reset! ct-test-state nil)))))

(defn- ct-on-summary [_m]
  (let [{:keys [test pass fail error]} @ct-counters]
    (println)
    (println (str "clojure.test Allure: "
               test " tests, "
               pass " passed, "
               fail " failed, "
               error " errors"))
    (println (str "Results written to " (:output-dir-path @ct-run-state) "/")))
  (finalize-ct-run!))

;; Global defmethod hooks

(defonce ^:private ct-originals
  {:begin-test-ns  (get-method ct/report :begin-test-ns)
   :end-test-ns    (get-method ct/report :end-test-ns)
   :begin-test-var (get-method ct/report :begin-test-var)
   :end-test-var   (get-method ct/report :end-test-var)
   :pass           (get-method ct/report :pass)
   :fail           (get-method ct/report :fail)
   :error          (get-method ct/report :error)
   :summary        (get-method ct/report :summary)})

(defmethod ct/report :begin-test-ns [m]
  (when (ct-enabled?)
    (ensure-ct-run-started!)
    (ct-on-begin-ns m))
  ((:begin-test-ns ct-originals) m))

(defmethod ct/report :end-test-ns [m]
  (when (ct-enabled?)
    (ct-on-end-ns m))
  ((:end-test-ns ct-originals) m))

(defmethod ct/report :begin-test-var [m]
  (when (ct-enabled?)
    (ct-on-begin-var m))
  ((:begin-test-var ct-originals) m))

(defmethod ct/report :end-test-var [m]
  (when (ct-enabled?)
    (ct-on-end-var m))
  ((:end-test-var ct-originals) m))

(defmethod ct/report :pass [m]
  ((:pass ct-originals) m)
  (when (ct-enabled?)
    (ct-on-pass m)))

(defmethod ct/report :fail [m]
  ((:fail ct-originals) m)
  (when (ct-enabled?)
    (ct-on-fail m)))

(defmethod ct/report :error [m]
  ((:error ct-originals) m)
  (when (ct-enabled?)
    (ct-on-error m)))

(defmethod ct/report :summary [m]
  ((:summary ct-originals) m)
  (when (and (ct-enabled?) @ct-run-state)
    (ct-on-summary m)))
