(ns com.blockether.spel.test-server
  "Local HTTP test server for integration tests.

   Provides HTML pages, echo/health/status endpoints, and request logging.
   NOT part of the public API — only used by our own test suite."
  (:require
   [clojure.java.io :as io]
   [com.blockether.spel.allure :refer [around]])
  (:import
   [com.sun.net.httpserver HttpServer HttpHandler HttpExchange]
   [java.net InetSocketAddress]))

(def ^{:dynamic true :doc "Base URL of the running test HTTP server."}
  *test-server-url* nil)

(def ^:private request-log (atom []))

(defn test-server-requests [] @request-log)

(defn- read-request-body ^String [^HttpExchange exchange]
  (let [is (.getRequestBody exchange)]
    (try (slurp is) (finally (.close is)))))

(defn- send-response [^HttpExchange exchange status ^String body content-type]
  (let [headers (.getResponseHeaders exchange)
        body-bytes (.getBytes body "UTF-8")]
    (.set headers "Content-Type" content-type)
    (.sendResponseHeaders exchange status (alength body-bytes))
    (let [os (.getResponseBody exchange)]
      (.write os body-bytes)
      (.close os))))

(def ^:private test-page-html
  "<!DOCTYPE html>
<html><head><title>Test Page</title></head>
<body>
  <h1 id=\"heading\">Test Heading</h1>
  <p id=\"description\">Test description paragraph.</p>
  <div id=\"content\">
    <a id=\"link\" href=\"/second-page\">Go to Second Page</a>
    <form id=\"test-form\">
      <label for=\"text-input\">Name</label>
      <input type=\"text\" id=\"text-input\" placeholder=\"Enter text\" aria-label=\"Name\" />
      <input type=\"text\" id=\"prefilled\" value=\"initial value\" />
      <input type=\"password\" id=\"password-input\" placeholder=\"Password\" />
      <input type=\"checkbox\" id=\"checkbox\" />
      <input type=\"checkbox\" id=\"checked-box\" checked />
      <select id=\"dropdown\">
        <option value=\"a\">Option A</option>
        <option value=\"b\">Option B</option>
        <option value=\"c\">Option C</option>
      </select>
      <textarea id=\"textarea\"></textarea>
      <input type=\"file\" id=\"file-input\" />
      <button id=\"submit-btn\" type=\"button\" data-testid=\"submit\">Submit</button>
    </form>
    <button id=\"hidden-btn\" style=\"display:none\">Hidden</button>
    <button id=\"disabled-btn\" disabled>Disabled</button>
    <ul role=\"listbox\"><li role=\"option\" id=\"aria-disabled-opt\" aria-disabled=\"true\">Disabled Option</li><li role=\"option\" id=\"aria-enabled-opt\">Enabled Option</li></ul>
    <div id=\"hover-target\" title=\"Hover tooltip\">Hover Me</div>
    <div id=\"scroll-anchor\" style=\"margin-top:2000px\">Scroll Target</div>
    <img id=\"logo\" alt=\"Test Logo\" src=\"data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7\" />
  </div>
  <script>
    window.testReady = true;
    console.log('test-page-loaded');
  </script>
</body></html>")

(def ^:private scrollable-page-html
  "<!DOCTYPE html>
<html><head><title>Scrollable Test Page</title>
<style>
  body { margin: 0; padding: 20px; height: 3000px; }
  .scroll-auto { width: 300px; height: 200px; overflow: auto; border: 1px solid #ccc; }
  .scroll-y    { width: 300px; height: 150px; overflow-y: scroll; overflow-x: hidden; border: 1px solid #aaa; }
  .no-overflow { width: 300px; height: 200px; overflow: hidden; border: 1px solid #eee; }
  .no-scroll   { width: 300px; height: 200px; overflow: visible; border: 1px solid #ddd; }
  .tall-content { height: 800px; }
  .wide-content { width: 600px; }
  #nested-outer { width: 400px; height: 300px; overflow: auto; border: 2px solid blue; }
  #nested-inner { width: 350px; height: 200px; overflow: auto; border: 2px solid green; margin: 10px; }
</style>
</head>
<body>
  <h1>Scrollable Test</h1>

  <!-- Scrollable: overflow:auto with tall content -->
  <div id=\"auto-scroll\" class=\"scroll-auto\" role=\"region\" aria-label=\"Auto Scroll\">
    <div class=\"tall-content\">Auto scroll content that overflows vertically</div>
  </div>

  <!-- Scrollable: overflow-y:scroll -->
  <div id=\"y-scroll\" class=\"scroll-y\">
    <div class=\"tall-content\">Y-scroll content that overflows</div>
  </div>

  <!-- NOT scrollable: overflow:hidden -->
  <div id=\"hidden-overflow\" class=\"no-overflow\">
    <div class=\"tall-content\">Hidden overflow — NOT scrollable</div>
  </div>

  <!-- NOT scrollable: no overflow, content fits -->
  <div id=\"no-overflow\" class=\"no-scroll\">
    <p>Short content that fits</p>
  </div>

  <!-- Nested scrollable containers -->
  <div id=\"nested-outer\">
    <div class=\"tall-content\">
      <div id=\"nested-inner\">
        <div class=\"tall-content\">Nested inner scrollable content</div>
      </div>
      Outer scrollable content
    </div>
  </div>

  <!-- Scroll position tracker -->
  <div id=\"scroll-pos\">0</div>
  <script>
    window.addEventListener('scroll', function() {
      document.getElementById('scroll-pos').textContent = Math.round(window.scrollY);
    });
  </script>
</body></html>")

(def ^:private keyboard-page-html
  "<!DOCTYPE html>
<html><head><title>Keyboard Test Page</title></head>
<body>
  <h1>Keyboard Test</h1>
  <div id=\"last-key\">none</div>
  <div id=\"key-log\"></div>
  <input type=\"text\" id=\"key-input\" placeholder=\"Type here\" />
  <script>
    document.addEventListener('keydown', function(e) {
      document.getElementById('last-key').textContent = e.key;
      var log = document.getElementById('key-log');
      log.textContent = (log.textContent ? log.textContent + ',' : '') + e.key;
    });
  </script>
</body></html>")

(def ^:private dialog-page-html
  "<!DOCTYPE html>
<html><head><title>Dialog Page</title></head>
<body>
  <h1>Dialog Test</h1>
  <button id=\"alert-btn\" onclick=\"alert('hello')\">Alert</button>
  <button id=\"confirm-btn\" onclick=\"document.getElementById('result').textContent = confirm('ok?')\">Confirm</button>
  <button id=\"prompt-btn\" onclick=\"document.getElementById('result').textContent = prompt('name?','default')\">Prompt</button>
  <div id=\"result\"></div>
</body></html>")

(def ^:private second-page-html
  "<!DOCTYPE html>
<html><head><title>Second Page</title></head>
<body>
  <h1 id=\"heading\">Second Page</h1>
  <a id=\"back-link\" href=\"/test-page\">Back to Test Page</a>
</body></html>")

(def ^:private iframe-page-html
  "<!DOCTYPE html>
<html><head><title>IFrame Page</title></head>
<body>
  <h1>IFrame Container</h1>
  <iframe id=\"test-iframe\" name=\"test-frame\" src=\"/test-page\" width=\"800\" height=\"600\"></iframe>
</body></html>")

(def ^:private markdown-layout-page-html
  "<!DOCTYPE html>
<html><head><title>Markdown Layout Page</title></head>
<body>
  <center>
    <table>
      <tr><td><a href=\"https://example.com/1\">First Story</a></td></tr>
      <tr><td><a href=\"https://example.com/2\">Second Story</a></td></tr>
    </table>
  </center>
</body></html>")

(def ^:private touch-page-html
  "Observable touch/gesture test page for the iOS provider (and any
   touch-capable backend). Every interaction leaves visible DOM state:
   - #last-action     — button taps/clicks write 'button-tapped'
   - #touch-log       — touchstart/touchend event names accumulate
   - #input-value     — mirrors the input's live value on input/change
   - #focus-state     — 'focused'/'blurred' for the input
   - #scroll-position — window scrollY, updated on scroll
   - #viewport-size   — innerWidth x innerHeight at load
   - #user-agent      — navigator.userAgent at load

   LAYOUT STABILITY IS LOAD-BEARING: every status div has a FIXED height.
   On iOS Safari the synthesized click is hit-tested ~100ms AFTER
   touchstart — if a touchstart handler grows #touch-log, everything below
   shifts and the click lands on the WRONG element. Keep it fixed."
  "<!DOCTYPE html>
<html><head><title>Touch Test Page</title>
<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\" />
<style>
  #last-action, #touch-log, #input-value, #focus-state, #scroll-position,
  #viewport-size, #user-agent {
    height: 20px; overflow: hidden; white-space: nowrap;
  }
</style>
</head>
<body>
  <h1>Touch Test</h1>
  <div id=\"last-action\">none</div>
  <div id=\"touch-log\"></div>
  <div id=\"input-value\">empty</div>
  <div id=\"focus-state\">blurred</div>
  <div id=\"scroll-position\">0</div>
  <div id=\"viewport-size\"></div>
  <div id=\"user-agent\"></div>
  <button id=\"tap-target\">Tap Me</button>
  <input type=\"text\" id=\"touch-input\" placeholder=\"Fill me\" />
  <a id=\"second-link\" href=\"/second-page\">Go to second page</a>
  <div id=\"tall-area\" style=\"height:3000px;background:linear-gradient(#fff,#ccc)\">tall scroll area</div>
  <div id=\"bottom-marker\">bottom</div>
  <script>
    var btn = document.getElementById('tap-target');
    btn.addEventListener('click', function() {
      document.getElementById('last-action').textContent = 'button-tapped';
    });
    ['touchstart','touchend'].forEach(function(evt) {
      btn.addEventListener(evt, function() {
        var log = document.getElementById('touch-log');
        log.textContent = (log.textContent ? log.textContent + ',' : '') + evt;
      });
    });
    var input = document.getElementById('touch-input');
    ['input','change'].forEach(function(evt) {
      input.addEventListener(evt, function() {
        document.getElementById('input-value').textContent = input.value || 'empty';
      });
    });
    input.addEventListener('focus', function() {
      document.getElementById('focus-state').textContent = 'focused';
    });
    input.addEventListener('blur', function() {
      document.getElementById('focus-state').textContent = 'blurred';
    });
    window.addEventListener('scroll', function() {
      document.getElementById('scroll-position').textContent = String(Math.round(window.scrollY));
    });
    document.getElementById('viewport-size').textContent =
      window.innerWidth + 'x' + window.innerHeight;
    document.getElementById('user-agent').textContent = navigator.userAgent;
  </script>
</body></html>")

(def ^:private navigation-assets-page-html
  (str "<!doctype html><title>Navigation assets</title><h1>Navigation assets</h1>"
    "<script>window.loadedAssets=0</script>"
    (apply str (for [i (range 400)]
                 (str "<script async src='/passive-asset.js?i=" i
                   "' onload='window.loadedAssets++'></script>")))))

(def ^:private navigation-fetches-page-html
  "<!doctype html><title>Navigation fetches</title><h1 id='loaded'>Loading</h1>
<script>
window.loadedAssets=0;
Promise.all(Array.from({length:400},(_,i)=>
  fetch('/health?i='+i).then(r=>r.json()).then(()=>window.loadedAssets++)))
  .then(()=>document.getElementById('loaded').textContent='Loaded '+window.loadedAssets);
</script>")

(defn- make-handler ^HttpHandler []
  (reify HttpHandler
    (handle [_ exchange]
      (let [method  (.toUpperCase (str (.getRequestMethod exchange)))
            uri     (.getRequestURI exchange)
            path    (.getPath uri)
            query   (.getQuery uri)
            headers (into {} (map (fn [[k vs]] [(str k) (first vs)]))
                      (.getRequestHeaders exchange))
            body    (read-request-body exchange)]
        (swap! request-log conj {:method method :path path :query query
                                 :headers headers :body body})
        (cond
          (and (= "GET" method) (= "/test-page" path))
          (send-response exchange 200 test-page-html "text/html; charset=UTF-8")

          (and (= "GET" method) (= "/second-page" path))
          (send-response exchange 200 second-page-html "text/html; charset=UTF-8")

          (and (= "GET" method) (= "/dialog-page" path))
          (send-response exchange 200 dialog-page-html "text/html; charset=UTF-8")

          (and (= "GET" method) (= "/iframe-page" path))
          (send-response exchange 200 iframe-page-html "text/html; charset=UTF-8")

          (and (= "GET" method) (= "/markdown-layout-page" path))
          (send-response exchange 200 markdown-layout-page-html "text/html; charset=UTF-8")

          (and (= "GET" method) (= "/keyboard-page" path))
          (send-response exchange 200 keyboard-page-html "text/html; charset=UTF-8")

          (and (= "GET" method) (= "/scrollable-page" path))
          (send-response exchange 200 scrollable-page-html "text/html; charset=UTF-8")

          (and (= "GET" method) (= "/touch-page" path))
          (send-response exchange 200 touch-page-html "text/html; charset=UTF-8")

          (and (= "GET" method) (= "/navigation-assets" path))
          (send-response exchange 200 navigation-assets-page-html "text/html; charset=UTF-8")

          (and (= "GET" method) (= "/navigation-fetches" path))
          (send-response exchange 200 navigation-fetches-page-html "text/html; charset=UTF-8")

          (and (= "GET" method) (= "/passive-asset.js" path))
          (send-response exchange 200 "window.__spelPassiveLoaded = true;" "application/javascript; charset=UTF-8")

          (and (= "GET" method) (= "/health" path))
          (send-response exchange 200 "{\"status\":\"ok\"}" "application/json")

          (and (= "HEAD" method) (= "/health" path))
          (do (.sendResponseHeaders exchange 200 -1)
              (.close (.getResponseBody exchange)))

          (= "/echo" path)
          (let [resp-body (str "{\"method\":\"" method "\""
                            ",\"path\":\"" path "\""
                            (when query (str ",\"query\":\"" query "\""))
                            (when (seq body) (str ",\"body\":" body))
                            "}")]
            (send-response exchange 200 resp-body "application/json"))

          (and (= "GET" method) (= "/redirect-page" path))
          (let [headers (.getResponseHeaders exchange)]
            (.set headers "Location" (str "http://localhost:" (.getPort (.getLocalAddress exchange)) "/test-page"))
            (.sendResponseHeaders exchange 301 -1)
            (.close (.getResponseBody exchange)))

          (and (= "GET" method) (= "/network-failure" path))
          (do
            ;; Delay the 500 so tests can distinguish request start from response time.
            (Thread/sleep 250)
            (.set (.getResponseHeaders exchange)
              "Set-Cookie" "trace-response=recorded; Path=/")
            (send-response exchange 500
              "{\"status\":500}"
              "application/json"))

          (.startsWith path "/status/")
          (let [code (Integer/parseInt (subs path 8))]
            (send-response exchange code
              (str "{\"status\":" code "}")
              "application/json"))

          (= "/slow" path)
          (do (Thread/sleep 2000)
              (send-response exchange 200 "{\"slow\":true}" "application/json"))

          :else
          (send-response exchange 404
            (str "{\"error\":\"not found\",\"path\":\"" path "\"}")
            "application/json"))))))

(defn start-test-server ^HttpServer []
  (let [server (HttpServer/create (InetSocketAddress. 0) 0)]
    (.createContext server "/" (make-handler))
    (.setExecutor server nil)
    (.start server)
    server))

(defn stop-test-server [^HttpServer server]
  (when server (.stop server 0)))

(defn server-port ^long [^HttpServer server]
  (.getPort (.getAddress server)))

(def with-test-server
  (around [f]
    (let [server (start-test-server)
          port   (server-port server)
          url    (str "http://localhost:" port)]
      (reset! request-log [])
      (try
        (binding [*test-server-url* url]
          (f))
        (finally
          (stop-test-server server))))))
