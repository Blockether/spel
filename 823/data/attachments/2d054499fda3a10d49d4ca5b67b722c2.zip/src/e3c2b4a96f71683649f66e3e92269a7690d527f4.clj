(ns com.blockether.spel.page-test
  (:require
   [clojure.string :as str]
   [com.blockether.anomaly.core :as anomaly]
   [com.blockether.spel.core :as core]
   [com.blockether.spel.page :as sut]
   [com.blockether.spel.locator :as locator]
   [com.blockether.spel.snapshot :as snapshot]
   [com.blockether.spel.test-server :refer [*test-server-url* with-test-server]]
   [com.blockether.spel.allure :refer [defdescribe describe expect expect-it it around]])
  (:import
   [com.microsoft.playwright Locator Frame Response CDPSession Route]
   [com.microsoft.playwright.options AriaRole]))

;; =============================================================================
;; Navigation
;; =============================================================================

(defdescribe navigate-test
  "Tests for page navigation"
  (around [f] (core/with-testing-browser (f)))

  (describe "navigate"
    (it "navigates to a URL"
      (core/with-testing-page [pg]
        (let [resp (sut/navigate pg "data:text/html,<h1>Hello</h1>")]
        ;; data: URLs return nil response
          (expect (or (nil? resp) (instance? Response resp))))))

    (expect-it "url returns current URL"
      (core/with-testing-page [pg]
        (do
          (sut/navigate pg "data:text/html,<h1>Test</h1>")
          (string? (sut/url pg)))))))

;; =============================================================================
;; Content
;; =============================================================================

(defdescribe content-test
  "Tests for page content"
  (around [f] (core/with-testing-browser (f)))

  (describe "content"
    (it "returns HTML content"
      (core/with-testing-page [pg]
        (sut/set-content! pg "<h1>Hello World</h1>")
        (let [html (sut/content pg)]
          (expect (string? html))
          (expect (.contains html "Hello World"))))))

  (describe "title"
    (expect-it "returns page title"
      (core/with-testing-page [pg]
        (do
          (sut/set-content! pg "<title>My Title</title><body>test</body>")
          (= "My Title" (sut/title pg)))))))

;; =============================================================================
;; Locators
;; =============================================================================

(defdescribe locator-test
  "Tests for page locator creation"
  (around [f] (core/with-testing-browser (f)))

  (describe "locator"
    (it "creates a CSS locator"
      (core/with-testing-page [pg]
        (sut/set-content! pg "<div class='test'>content</div>")
        (let [loc (sut/locator pg ".test")]
          (expect (instance? Locator loc))
          (expect (= "content" (locator/text-content loc)))))))

  (describe "get-by-text"
    (it "locates element by text"
      (core/with-testing-page [pg]
        (sut/set-content! pg "<span>Hello World</span>")
        (let [loc (sut/get-by-text pg "Hello World")]
          (expect (instance? Locator loc))
          (expect (locator/is-visible? loc)))))))

;; =============================================================================
;; Evaluation
;; =============================================================================

(defdescribe evaluate-test
  "Tests for JavaScript evaluation"
  (around [f] (core/with-testing-browser (f)))

  (describe "evaluate"
    (it "evaluates simple expression"
      (core/with-testing-page [pg]
        (let [result (sut/evaluate pg "1 + 2")]
          (expect (= 3 (long result))))))

    (it "evaluates with argument"
      (core/with-testing-page [pg]
        (let [result (sut/evaluate pg "x => x + '!'" "hello")]
          (expect (= "hello!" result)))))

    ;; Regression, vis#382 follow-up: Playwright refused a Clojure long and a
    ;; keyword-keyed map as the argument ("Unsupported type of argument: 21").
    (it "accepts Clojure numbers, keywords and nested collections as the argument"
      (core/with-testing-page [pg]
        (expect (= 42 (long (sut/evaluate pg "x => x * 2" 21))))
        (expect (= {"n" 21 "tags" ["a" "b"] "ok" true}
                  (sut/evaluate pg "x => ({n: x.n, tags: x.tags, ok: x.ok})"
                    {:n 21 :tags [:a "b"] :ok true})))))

    (it "tags a failing evaluation with the JS it ran"
      ;; The error layer frames :spel/source, so a Clojure form that evaluates
      ;; JS reports the JS that failed instead of the form.
      (core/with-testing-page [pg]
        (let [result (sut/evaluate pg "null.boom")]
          (expect (anomaly/anomaly? result))
          (expect (= "null.boom" (:spel/source result)))
          (expect (= :js (:spel/lang result))))))))

(defdescribe evaluate-file-test
  "Tests for evaluating JS loaded from disk"
  (around [f] (core/with-testing-browser (f)))

  (describe "evaluate-file"
    (it "runs the JS from the given file in the page"
      (core/with-testing-page [pg]
        (let [tmp (java.io.File/createTempFile "spel-eval-" ".js")]
          (try
            (spit tmp "({pi: Math.PI, env: 'browser'})")
            (let [r (sut/evaluate-file pg (.getAbsolutePath tmp))]
              (expect (= "browser" (get r "env")))
              (expect (< 3.14 (double (get r "pi")) 3.15)))
            (finally (.delete tmp))))))

    (it "passes an argument through to the JS expression"
      (core/with-testing-page [pg]
        (let [tmp (java.io.File/createTempFile "spel-eval-" ".js")]
          (try
            (spit tmp "s => s.toUpperCase()")
            (let [r (sut/evaluate-file pg (.getAbsolutePath tmp) "hi")]
              (expect (= "HI" r)))
            (finally (.delete tmp))))))

    (it "returns an anomaly when the file is missing"
      (core/with-testing-page [pg]
        (let [r (sut/evaluate-file pg "/tmp/definitely-not-a-real-spel-js-file.js")]
          (expect (anomaly/anomaly? r)))))))

(defdescribe add-init-script-test
  "Tests for Page.addInitScript wrappers"
  (around [f] (core/with-testing-browser (f)))

  (describe "add-init-script!"
    (it "runs before page navigation and is visible from the page"
      (core/with-testing-page [pg]
        (sut/add-init-script! pg "window.__spelInjected = 42;")
        (sut/navigate pg "data:text/html,<h1>init</h1>")
        (let [r (sut/evaluate pg "window.__spelInjected")]
          (expect (= 42 (long r)))))))

  (describe "add-init-script-file!"
    (it "loads the script from disk and exposes it to the page"
      (core/with-testing-page [pg]
        (let [tmp (java.io.File/createTempFile "spel-init-" ".js")]
          (try
            (spit tmp "window.__spelInjectedFromFile = 'yes';")
            (sut/add-init-script-file! pg (.getAbsolutePath tmp))
            (sut/navigate pg "data:text/html,<h1>init-file</h1>")
            (let [r (sut/evaluate pg "window.__spelInjectedFromFile")]
              (expect (= "yes" r)))
            (finally (.delete tmp))))))))

(defdescribe new-cdp-session-test
  "Tests for page.new-cdp-session + core cdp-send/detach"
  (around [f] (core/with-testing-browser (f)))

  (describe "new-cdp-session"
    (it "opens a CDP session and responds to a no-param command"
      (core/with-testing-page [pg]
        (sut/navigate pg "data:text/html,<h1>cdp</h1>")
        (let [sess (sut/new-cdp-session pg)]
          (expect (instance? CDPSession sess))
          (try
            (let [res (core/cdp-send sess "Page.getNavigationHistory")]
              (expect (not (anomaly/anomaly? res))))
            (finally (core/cdp-detach! sess))))))

    ;; Regression, user report: cdp-send sent every parameter value as a string, so
    ;; CDP refused any command with a number or a boolean as "Invalid parameters".
    (it "sends numbers and booleans with their JSON types and returns Clojure data"
      (core/with-testing-page [pg]
        (sut/navigate pg "data:text/html,<div style='height:5000px'>tall</div>")
        (let [sess (sut/new-cdp-session pg)]
          (try
            (let [wheel  (core/cdp-send sess "Input.dispatchMouseEvent"
                           {:type "mouseWheel" :x 20 :y 20 :deltaX 0 :deltaY 400})
                  scroll (fn []
                           (get-in (core/cdp-send sess "Runtime.evaluate"
                                     {:expression "window.scrollY" :returnByValue true})
                             ["result" "value"]))]
              (expect (= {} wheel))
              (expect (pos? (or (some (fn [_] (Thread/sleep 50) (let [y (scroll)] (when (pos? y) y)))
                                  (range 40))
                              0))))
            (finally (core/cdp-detach! sess))))))

    ;; Regression, user report: cdp-on handed the raw Gson object to the handler, so
    ;; (get event "sessionId") was nil and a screencast stopped without its frame ack.
    (it "hands cdp-on handlers the event as a map with string keys"
      (core/with-testing-page [pg]
        (sut/navigate pg "data:text/html,<h1>frames</h1>")
        (let [sess   (sut/new-cdp-session pg)
              frames (atom [])]
          (try
            (core/cdp-on sess "Page.screencastFrame"
              (fn [event]
                (swap! frames conj event)
                (core/cdp-send sess "Page.screencastFrameAck" {:sessionId (get event "sessionId")})))
            (core/cdp-send sess "Page.bringToFront")
            (expect (= {} (core/cdp-send sess "Page.startScreencast"
                            {:format "jpeg" :quality 30 :maxWidth 200 :everyNthFrame 1})))
            ;; Chromium sends a frame only after a paint, so repaint until one arrives.
            (expect (some (fn [i]
                            (sut/evaluate pg (str "document.querySelector('h1').textContent = 'frame " i "'"))
                            (Thread/sleep 50)
                            (seq @frames))
                      (range 200)))
            (core/cdp-send sess "Page.stopScreencast")
            (let [event (first @frames)]
              (expect (map? event))
              (expect (string? (get event "data")))
              (expect (number? (get event "sessionId"))))
            (finally (core/cdp-detach! sess))))))))

;; =============================================================================
;; Screenshots
;; =============================================================================

(defdescribe screenshot-test
  "Tests for screenshot capture"
  (around [f] (core/with-testing-browser (f)))

  (describe "screenshot"
    (it "takes screenshot as byte array"
      (core/with-testing-page [pg]
        (sut/set-content! pg "<h1>Screenshot Test</h1>")
        (let [bytes (sut/screenshot pg)]
          (expect (bytes? bytes))
          (expect (pos? (alength ^bytes bytes))))))))

;; =============================================================================
;; Page State
;; =============================================================================

(defdescribe page-state-test
  "Tests for page state queries"
  (around [f] (core/with-testing-browser (f)))

  (describe "is-closed?"
    (it "returns false for open page"
      (core/with-playwright [pw (core/create)]
        (core/with-browser [browser (core/launch-chromium pw {:headless true})]
          (core/with-page [page (core/new-page browser)]
            (expect (false? (sut/is-closed? page)))))))

    (it "returns true after closing"
      (core/with-playwright [pw (core/create)]
        (core/with-browser [browser (core/launch-chromium pw {:headless true})]
          (let [page (core/new-page browser)]
            (core/close-page! page)
            (expect (true? (sut/is-closed? page))))))))

  (describe "viewport-size"
    (it "returns viewport dimensions"
      (core/with-testing-page [pg]
        (sut/set-viewport-size! pg 1024 768)
        (let [vp (sut/viewport-size pg)]
          (expect (= 1024 (:width vp)))
          (expect (= 768 (:height vp)))))))

  (describe "frames"
    (expect-it "returns main frame"
      (core/with-testing-page [pg]
        (instance? Frame (sut/main-frame pg))))))

;; =============================================================================
;; once-dialog
;; =============================================================================

(defdescribe once-dialog-test
  "Tests for one-time dialog handler"
  (around [f] (core/with-testing-browser (f)))

  (describe "once-dialog"

    (it "fires handler for first dialog"
      (core/with-testing-page [pg]
        (let [captured (atom nil)]
          (sut/once-dialog pg (fn [dialog]
                                (reset! captured (.message dialog))
                                (.dismiss dialog)))
          (sut/evaluate pg "window.alert('hello once')")
          (expect (= "hello once" @captured)))))

    (it "does not fire for second dialog"
      (core/with-testing-page [pg]
        (let [once-count (atom 0)]
        ;; Register persistent handler to dismiss all dialogs
          (sut/on-dialog pg (fn [dialog] (.dismiss dialog)))
        ;; Register one-time handler that increments counter
          (sut/once-dialog pg (fn [_dialog]
                                (swap! once-count inc)))
        ;; First alert — once-dialog fires
          (sut/evaluate pg "window.alert('first')")
          (expect (= 1 @once-count))
        ;; Second alert — once-dialog already consumed, does not fire again
          (sut/evaluate pg "window.alert('second')")
          (expect (= 1 @once-count)))))))

;; Regression, user report: FULL_API.md promised `off-dialog [page handler]`
;; removed a dialog handler, and nothing could ever remove one — `on-dialog`
;; hands Playwright a guard built around the handler and Playwright unregisters
;; by object identity, so passing the handler function back threw a
;; ClassCastException instead of taking the listener off.
(defdescribe off-dialog-test
  "Tests for removing a dialog handler"
  (around [f] (core/with-testing-browser (f)))

  (describe "off-dialog"

    (it "stops the handler on-dialog registered"
      (core/with-testing-page [pg]
        (let [seen     (atom 0)
              listener (sut/on-dialog pg (fn [dialog]
                                           (swap! seen inc)
                                           (.dismiss dialog)))]
          (sut/evaluate pg "window.alert('one')")
          (expect (= 1 @seen))
          (sut/off-dialog pg listener)
          ;; With no listener left Playwright dismisses the dialog itself, so
          ;; the page keeps running and the counter must stay where it was.
          (sut/evaluate pg "window.alert('two')")
          (expect (= 1 @seen)))))

    (it "refuses the handler function, which Playwright could never match"
      (core/with-testing-page [pg]
        (let [handler (fn [dialog] (.dismiss dialog))]
          (sut/on-dialog pg handler)
          (expect (anomaly/anomaly? (sut/off-dialog pg handler))))))))
;; =============================================================================
;; get-by-role with options
;; =============================================================================

(def ^:private role-test-html
  "<html><body>
     <h1>Title</h1><h2>Subtitle</h2><h3>Section</h3>
     <button>Cancel</button><button>Submit</button>
     <input type='checkbox' id='c1' checked/><label for='c1'>Agree</label>
     <input type='checkbox' id='c2'/><label for='c2'>Newsletter</label>
   </body></html>")

(defdescribe get-by-role-options-test
  "Tests for get-by-role with options map"
  (around [f] (core/with-testing-browser (f)))

  (describe "get-by-role with :name"

    (it "finds button by name"
      (core/with-testing-page [pg]
        (sut/set-content! pg role-test-html)
        (let [loc (sut/get-by-role pg AriaRole/BUTTON {:name "Submit"})]
          (expect (instance? Locator loc))
          (expect (= "Submit" (locator/text-content loc)))))))

  (describe "get-by-role with :name :exact"

    (it "finds exact name match"
      (core/with-testing-page [pg]
        (sut/set-content! pg role-test-html)
        (let [loc (sut/get-by-role pg AriaRole/BUTTON {:name "Submit" :exact true})]
          (expect (= "Submit" (locator/text-content loc)))))))

  (describe "get-by-role with :level"

    (it "finds heading by level"
      (core/with-testing-page [pg]
        (sut/set-content! pg role-test-html)
        (let [loc (sut/get-by-role pg AriaRole/HEADING {:level 2})]
          (expect (= "Subtitle" (locator/text-content loc)))))))

  (describe "get-by-role with :checked"

    (it "finds checked checkbox"
      (core/with-testing-page [pg]
        (sut/set-content! pg role-test-html)
        (let [loc (sut/get-by-role pg AriaRole/CHECKBOX {:checked true})]
          (expect (= 1 (locator/count-elements loc)))
          (expect (true? (locator/is-checked? loc))))))))

;; =============================================================================
;; get-by-ref
;; =============================================================================

(defdescribe get-by-ref-test
  "Tests for get-by-ref locator"
  (around [f] (core/with-testing-browser (f)))

  (describe "get-by-ref with snapshot refs"

    (it "locates element by ref ID after snapshot"
      (core/with-testing-page [pg]
        (sut/set-content! pg "<h1>Hello</h1><button>Click me</button>")
        ;; Take snapshot to tag elements with data-pw-ref
        (let [snap (snapshot/capture-snapshot pg)
              refs (:refs snap)
              ref-id (first (keys refs))
              loc (sut/get-by-ref pg ref-id)]
          (expect (instance? Locator loc))
          (expect (locator/is-visible? loc)))))

    (it "locates element by @ref ID (strips @ prefix)"
      (core/with-testing-page [pg]
        (sut/set-content! pg "<p>Some text</p>")
        (let [snap (snapshot/capture-snapshot pg)
              refs (:refs snap)
              ref-id (first (keys refs))
              loc (sut/get-by-ref pg (str "@" ref-id))]
          (expect (instance? Locator loc))
          (expect (locator/is-visible? loc)))))

    (it "returns empty locator for non-existent ref"
      (core/with-testing-page [pg]
        (sut/set-content! pg "<div>Test</div>")
        (let [loc (sut/get-by-ref pg "e9999")]
          (expect (instance? Locator loc))
          (expect (= 0 (locator/count-elements loc))))))))

(defdescribe validate-url-test
  "Tests for URL validation logic"
  (around [f] (core/with-testing-browser (f)))

  (describe "validate-url"
    (it "returns valid URLs as-is"
      (expect (= "https://example.org" (sut/validate-url "https://example.org")))
      (expect (= "http://example.org" (sut/validate-url "http://example.org")))
      (expect (= "https://sub.example.org" (sut/validate-url "https://sub.example.org")))
      (expect (= "https://example.org/path" (sut/validate-url "https://example.org/path")))
      (expect (= "https://example.org?q=1" (sut/validate-url "https://example.org?q=1")))
      (expect (= "https://example.org#frag" (sut/validate-url "https://example.org#frag")))
      (expect (= "http://localhost" (sut/validate-url "http://localhost")))
      (expect (= "http://localhost:3000" (sut/validate-url "http://localhost:3000")))
      (expect (= "https://192.168.1.1" (sut/validate-url "https://192.168.1.1")))
      (expect (= "https://192.168.1.1:8080" (sut/validate-url "https://192.168.1.1:8080")))
      (expect (= "file:///tmp/test.html" (sut/validate-url "file:///tmp/test.html")))
      (expect (= "about:blank" (sut/validate-url "about:blank")))
      (expect (= "data:text/html,<h1>hi</h1>" (sut/validate-url "data:text/html,<h1>hi</h1>")))
      (expect (= "chrome://settings" (sut/validate-url "chrome://settings")))
      (expect (= "javascript:void(0)" (sut/validate-url "javascript:void(0)")))
      (expect (= "blob:http://example.org/abc" (sut/validate-url "blob:http://example.org/abc")))
      (expect (= "https://example.co.uk" (sut/validate-url "https://example.co.uk"))))

    (it "throws for invalid single-word domain"
      (let [err (try (sut/validate-url "https://not-a-url") nil
                     (catch clojure.lang.ExceptionInfo e e))]
        (expect (some? err))
        (expect (str/includes? (.getMessage err) "Invalid URL"))))

    (it "throws for invalid single word"
      (let [err (try (sut/validate-url "https://invalid") nil
                     (catch clojure.lang.ExceptionInfo e e))]
        (expect (some? err))
        (expect (str/includes? (.getMessage err) "Invalid URL"))))

    (it "error message includes raw input"
      (let [err (try (sut/validate-url "https://notaurl" "notaurl") nil
                     (catch clojure.lang.ExceptionInfo e e))]
        (expect (some? err))
        (expect (str/includes? (.getMessage err) "notaurl"))))))

;; =============================================================================
;; Clipboard
;; =============================================================================

(defdescribe clipboard-test
  "Tests for page clipboard operations"
  (around [f] (core/with-testing-browser (f)))

  (describe "clipboard-copy and clipboard-read"
    (it "copies text and reads it back"
      (core/with-testing-page [pg]
        (sut/set-content! pg "<body>clipboard test</body>")
        (let [result (sut/clipboard-copy pg "hello from test")]
          (expect (= true (:copied result)))
          (expect (= "hello from test" (:text result))))))

    (it "reads back the text that was copied"
      (core/with-testing-page [pg]
        (sut/set-content! pg "<body>read test</body>")
        (sut/clipboard-copy pg "round-trip value")
        (let [result (sut/clipboard-read pg)]
        ;; Clipboard API requires secure context (localhost/https);
        ;; on about:blank, readText may fail. Assert structure, not content.
          (expect (map? result))
          (expect (or (contains? result :content)
                    (some? (:com.blockether.anomaly.core/category result))))))))

  (describe "clipboard-paste"
    (it "returns paste result structure"
      (core/with-testing-page [pg]
        (sut/set-content! pg "<input id='target' type='text'/>")
        (locator/click (sut/locator pg "#target"))
        (sut/clipboard-copy pg "pasted text")
        (let [result (sut/clipboard-paste pg)]
        ;; Clipboard paste may fail on about:blank (no secure context)
        ;; Just verify the function returns a map without crashing
          (expect (map? result)))))))

;; =============================================================================
;; Event Handler Safety — regression for the wedged-session bug
;; =============================================================================

(defdescribe route-handler-safety-test
  "Regression: a broken route handler must not wedge navigation.

   Playwright runs route handlers on its own dispatch thread and swallows the
   exception. An intercepted request that is never resumed, aborted or fulfilled
   hangs the navigation FOREVER — no timeout, no log line — which is how a single
   `(fn [route _] ...)` wedged whole daemon sessions until the command budget
   killed them. `route!` now guards the handler and resumes the route."
  (around [f] (core/with-testing-browser ((:around with-test-server) f)))

  (describe "a two-argument handler — the most common mistake"
    (it "navigation completes instead of hanging forever"
      (core/with-testing-page [pg]
        (sut/route! pg "**/*" (fn [_route _extra] :never))
        (let [resp (sut/navigate pg (str *test-server-url* "/health"))]
          (expect (some? resp))
          (expect (= 200 (.status ^Response resp)))
          (expect (str/includes? (sut/content pg) "ok"))))))

  (describe "a handler that throws"
    (it "is released and navigation completes"
      (core/with-testing-page [pg]
        (sut/route! pg "**/*" (fn [_route] (throw (ex-info "handler blew up" {}))))
        (let [resp (sut/navigate pg (str *test-server-url* "/health"))]
          (expect (some? resp))
          (expect (= 200 (.status ^Response resp)))))))

  (describe "a well-formed handler still routes"
    (it "runs the handler and lets it answer the request"
      (core/with-testing-page [pg]
        (let [seen (atom 0)]
          (sut/route! pg "**/*" (fn [route] (swap! seen inc) (.resume ^Route route)))
          (let [resp (sut/navigate pg (str *test-server-url* "/health"))]
            (expect (some? resp))
            (expect (pos? @seen))
            (expect (str/includes? (sut/content pg) "ok"))))))))
