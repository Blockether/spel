(ns com.blockether.spel.annotate-test
  "Tests for the annotate namespace.

   Unit tests verify JS generation logic, annotation filtering, and
   containment dedup (no browser needed).
   Integration tests run against example.org using Playwright."
  (:require
   [com.blockether.spel.annotate :as sut]
   [clojure.string :as str]
   [com.blockether.spel.page :as page]
   [com.blockether.spel.snapshot :as snapshot]
   [com.blockether.spel.core :as core]
   [com.blockether.spel.example-domain :as example]
   [com.blockether.spel.allure :refer [around defdescribe describe expect it]])
  (:import
   [java.io ByteArrayInputStream File]
   [javax.imageio ImageIO]))

;; =============================================================================
;; Helpers
;; =============================================================================

(def ^:private test-refs
  {"e1" {:role "button" :name "Submit" :bbox {:x 10 :y 20 :width 60 :height 25}}
   "e2" {:role "link"   :name "Home"   :bbox {:x 5  :y 50 :width 40 :height 15}}
   "e3" {:role "heading" :name "Title" :bbox {:x 10 :y 5  :width 80 :height 20}}})

(defn- inject-js
  "The overlay script for `refs`, as `inject-overlays!` builds it."
  [refs opts]
  (#'sut/build-inject-js (sut/refs->entries refs) opts))

(def ^:private controls-html
  "<html><body style='margin:20px'><h1>Title</h1><button>Submit</button> <a href='#'>Home</a></body></html>")

(defn- drawn
  "Draws the overlays for `controls-html` and returns the drawn nodes as
   [kind text] pairs, without the root."
  [pg opts]
  (page/set-content! pg controls-html)
  (let [snap  (snapshot/capture-snapshot pg)
        _     (sut/inject-overlays! pg (:refs snap) opts)
        nodes (page/evaluate pg
                (str "Array.from(document.querySelectorAll('[data-spel-annotate]'))"
                  ".filter(function(e){return e.getAttribute('data-spel-annotate') !== 'root';})"
                  ".map(function(e){return [e.getAttribute('data-spel-annotate'), e.textContent];})"))]
    (sut/remove-overlays! pg)
    (mapv vec nodes)))

;; =============================================================================
;; Unit Tests — bundled typography
;; =============================================================================

(defdescribe report-fonts-test
  "The report document ships its fonts instead of fetching them"

  (describe "report->html typography"

    (it "bundles every face as a data URI and never links a font CDN"
      (let [html (sut/report->html [{:type :text :text "hello"}] {:title "Fonts"})]
        (expect (not (str/includes? html "fonts.googleapis.com")))
        (expect (not (str/includes? html "fonts.gstatic.com")))
        (expect (not (str/includes? html "<link")))
        (expect (= 4 (count (re-seq #"data:font/woff2;base64," html))))
        (expect (str/includes? html "--font-body:'Inter Variable'"))
        (expect (str/includes? html "--font-mono:'JetBrains Mono Variable'"))))))

;; =============================================================================
;; Unit Tests — JS overlay generation
;; =============================================================================

(defdescribe build-inject-js-test
  "Unit tests for JS overlay injection script generation"
  (around [f] (core/with-testing-browser (f)))

  (describe "basic JS generation"
    (it "produces a non-empty JS string"

      (core/with-testing-page [_pg] (let [js (inject-js test-refs {})]
                                      (expect (string? js))
                                      (expect (pos? (count js))))))

    (it "contains the root container setup"

      (core/with-testing-page [_pg] (let [js (inject-js test-refs {})]
                                      (expect (.contains ^String js "data-spel-annotate"))
                                      (expect (.contains ^String js "z-index:2147483647"))
                                      (expect (.contains ^String js "pointer-events:none")))))

    (it "labels carry the mark number only — never the ref id, role or size"

      ;; Regression: the label spelled "e4khqh textbox 153x21", ~150px of ink for
      ;; a 153x21 control, so on a form every badge covered the neighbouring
      ;; field's own label. The mark is the number; the table carries the rest.
      (core/with-testing-page [pg] (let [marks (keep (fn [[kind text]] (when (= "mark" kind) text)) (drawn pg {}))]
                                     (expect (= ["1" "2" "3"] (sort marks))))))

    (it "numbers marks in reading order, exactly as refs->entries reports them"

      (core/with-testing-page [_pg] (let [entries (sut/refs->entries test-refs)]
                                      (expect (= [1 2 3] (mapv :mark entries)))
                                      (expect (= ["e3" "e1" "e2"] (mapv :ref entries))))))

    (it "stamps the ref on the drawn mark so a click target stays reachable"

      (core/with-testing-page [_pg] (let [js (inject-js test-refs {})]
                                      (expect (.contains ^String js "data-spel-ref")))))

    (it "uses the Blockether brand palette (amber box, ink chip)"

      (core/with-testing-page [_pg] (let [js (inject-js test-refs {})]
        ;; box + mark → the first palette colour, one hue per entry
                                      (expect (.contains ^String js "#d7263d"))
                                      (expect (.contains ^String js "#ffffff"))
        ;; mark chip → JetBrains Mono
                                      (expect (.contains ^String js "JetBrains Mono"))))))

  (describe "mark placement"
    (it "keeps the mark off an isolated control and parks it in the margin beside it"

      (core/with-testing-page [pg]
        (page/set-content! pg "<html><body style='margin:0'><button id='b' style='position:absolute;left:100px;top:100px;width:300px;height:200px'>Save</button></body></html>")
        (let [snap (snapshot/capture-snapshot pg)
              _    (sut/inject-overlays! pg (:refs snap))
              geo  (page/evaluate pg
                     (str "(function(){"
                       "var m = document.querySelector('[data-spel-annotate=\"mark\"]').getBoundingClientRect();"
                       "var b = document.getElementById('b').getBoundingClientRect();"
                       "var apart = m.right <= b.left + 1 || m.left >= b.right - 1 || m.bottom <= b.top + 1 || m.top >= b.bottom - 1;"
                       "var near = Math.max(b.left - m.right, m.left - b.right, b.top - m.bottom, m.top - b.bottom) <= 4;"
                       "return [apart ? 1 : 0, near ? 1 : 0, Math.round(m.width)];})()"))
              [apart near width] (mapv long geo)]
          (expect (= 1 apart))
          (expect (= 1 near))
          ;; A mark is a number, not a caption: it stays narrow enough to park.
          (expect (< width 40))
          (sut/remove-overlays! pg))))

    (it "clamps every candidate inside the document"

      (core/with-testing-page [_pg] (let [js (inject-js test-refs {})]
                                      (expect (.contains ^String js "docW - mw"))
                                      (expect (.contains ^String js "docH - mh"))))))

  (describe "option toggles"
    (it "excludes boxes when :show-boxes false"

      (core/with-testing-page [pg] (let [kinds (frequencies (map first (drawn pg {:show-boxes false})))]
        ;; Should still have marks, but no box outline divs
                                     (expect (= {"mark" 3} kinds)))))

    (it "excludes marks when :show-badges false"

      (core/with-testing-page [pg] (let [kinds (frequencies (map first (drawn pg {:show-badges false})))]
        ;; No mark elements, but the boxes stay
                                     (expect (= {"box" 3} kinds)))))

    (it "adds dimensions to the mark only when :show-dimensions true"

      (core/with-testing-page [pg] (let [texts (fn [opts] (keep (fn [[kind text]] (when (= "mark" kind) text)) (drawn pg opts)))]
                                     (expect (every? #(re-matches #"\d+" %) (texts {})))
                                     (expect (= 3 (count (texts {:show-dimensions true}))))
                                     (expect (every? #(re-matches #"\d+ \d+x\d+" %) (texts {:show-dimensions true}))))))

    (it "draws nothing with all options disabled"

      (core/with-testing-page [pg] (expect (= [] (drawn pg {:show-boxes false
                                                            :show-badges false
                                                            :show-dimensions false}))))))

  (describe "edge cases"
    (it "handles empty refs map"

      (core/with-testing-page [_pg] (let [js (inject-js {} {})]
                                      (expect (string? js))
        ;; Should still set up the container
                                      (expect (.contains ^String js "data-spel-annotate")))))

    (it "handles single ref"

      (core/with-testing-page [_pg] (let [js (inject-js {"e1" {:role "button" :name "OK"
                                                                     :bbox {:x 10 :y 10 :width 30 :height 20}}} {})]
                                      (expect (.contains ^String js "[[\"e1\",1]]")))))

    (it "skips refs with zero-size bbox"

      (core/with-testing-page [_pg] (let [js (inject-js {"e1" {:role "button" :name "Hidden"
                                                                     :bbox {:x 0 :y 0 :width 0 :height 0}}} {})]
        ;; Zero-size bbox should be filtered out
                                      (expect (not (.contains ^String js "\"e1\""))))))))

;; =============================================================================
;; Unit Tests — annotation filtering
;; =============================================================================

(defdescribe filter-annotatable-test
  "Unit tests for structural role filtering and containment dedup"
  (around [f] (core/with-testing-browser (f)))

  (describe "structural role filtering"
    (it "keeps interactive roles (button, link, textbox)"

      (core/with-testing-page [_pg] (let [refs {"e1" {:role "button" :bbox {:x 0 :y 0 :width 50 :height 20}}
                                                "e2" {:role "link"   :bbox {:x 0 :y 30 :width 50 :height 20}}
                                                "e3" {:role "textbox" :bbox {:x 0 :y 60 :width 50 :height 20}}}
                                          result (sut/filter-annotatable refs)]
                                      (expect (= 3 (count result)))
                                      (expect (contains? result "e1"))
                                      (expect (contains? result "e2"))
                                      (expect (contains? result "e3")))))

    (it "keeps content anchors (heading, img)"

      (core/with-testing-page [_pg] (let [refs {"e1" {:role "heading" :bbox {:x 0 :y 0 :width 100 :height 30}}
                                                "e2" {:role "img"     :bbox {:x 0 :y 40 :width 100 :height 80}}}
                                          result (sut/filter-annotatable refs)]
                                      (expect (= 2 (count result))))))

    (it "removes pure structural roles (list, region)"

      (core/with-testing-page [_pg] (let [refs {"e1" {:role "list"   :bbox {:x 0 :y 30 :width 300 :height 100}}
                                                "e2" {:role "region" :bbox {:x 0 :y 0 :width 500 :height 500}}}
                                          result (sut/filter-annotatable refs)]
                                      (expect (= 0 (count result))))))

    (it "keeps listitem role only with :show-text"

      (core/with-testing-page [_pg] (let [refs {"e1" {:role "listitem" :bbox {:x 0 :y 30 :width 300 :height 25}}}]
                                      (expect (= 0 (count (sut/filter-annotatable refs))))
                                      (expect (contains? (sut/filter-annotatable refs {:show-text true}) "e1")))))

    (it "drops text containers (paragraph, span) by default"

      (core/with-testing-page [_pg] (let [refs {"e1" {:role "paragraph" :bbox {:x 0 :y 0 :width 300 :height 20}}
                                                "e2" {:role "span"      :bbox {:x 0 :y 30 :width 100 :height 15}}}]
        ;; Prose is in the snapshot; the overlay answers what can be acted on.
                                      (expect (= 0 (count (sut/filter-annotatable refs))))
                                      (expect (= 2 (count (sut/filter-annotatable refs {:show-text true})))))))

    (it "keeps text role only with :show-text (generic divs with text content)"

      (core/with-testing-page [_pg] (let [refs {"e1" {:role "text" :bbox {:x 0 :y 0 :width 200 :height 20}}}]
                                      (expect (= 0 (count (sut/filter-annotatable refs))))
                                      (expect (contains? (sut/filter-annotatable refs {:show-text true}) "e1")))))

    (it "paragraph wrapping link is removed by containment dedup"

      (core/with-testing-page [_pg] (let [refs {"e1" {:role "paragraph" :bbox {:x 0 :y 0 :width 300 :height 20}}
                                                "e2" {:role "link"      :bbox {:x 5 :y 2 :width 60  :height 16}}
                                                "e3" {:role "heading"   :bbox {:x 0 :y 30 :width 300 :height 30}}}
                                          result (sut/filter-annotatable refs)]
        ;; e1 paragraph contains e2 link → e1 suppressed by containment dedup
                                      (expect (= 2 (count result)))
                                      (expect (contains? result "e2"))
                                      (expect (contains? result "e3"))
                                      (expect (not (contains? result "e1")))))))

  (describe "containment dedup"
    (it "removes container whose bbox fully wraps a child"

      (core/with-testing-page [_pg] (let [refs {"e1" {:role "navigation" :bbox {:x 0 :y 0 :width 500 :height 100}}
                                                "e2" {:role "link"       :bbox {:x 10 :y 10 :width 60 :height 20}}}
                                          result (sut/filter-annotatable refs)]
        ;; navigation contains link → navigation suppressed
                                      (expect (= 1 (count result)))
                                      (expect (contains? result "e2")))))

    (it "keeps both when neither contains the other"

      (core/with-testing-page [_pg] (let [refs {"e1" {:role "button" :bbox {:x 0  :y 0  :width 60 :height 20}}
                                                "e2" {:role "link"   :bbox {:x 80 :y 0  :width 60 :height 20}}}
                                          result (sut/filter-annotatable refs)]
                                      (expect (= 2 (count result))))))

    (it "handles nested containment (grandparent → parent → child)"

      (core/with-testing-page [_pg] (let [refs {"e1" {:role "navigation" :bbox {:x 0 :y 0 :width 500 :height 100}}
                                                "e2" {:role "dialog"     :bbox {:x 5 :y 5 :width 200 :height 50}}
                                                "e3" {:role "button"     :bbox {:x 10 :y 10 :width 60 :height 20}}}
                                          result (sut/filter-annotatable refs)]
        ;; e1 contains e2 and e3 → e1 removed
        ;; e2 contains e3 → e2 removed
        ;; Only e3 (button) survives
                                      (expect (= 1 (count result)))
                                      (expect (contains? result "e3")))))

    (it "handles identical bboxes by keeping both elements"

      (core/with-testing-page [_pg] (let [refs {"e1" {:role "button"  :bbox {:x 10 :y 10 :width 60 :height 20}}
                                                "e2" {:role "heading" :bbox {:x 10 :y 10 :width 60 :height 20}}}
                                          result (sut/filter-annotatable refs)]
        ;; Same bbox → neither is a "container" → both kept
        ;; (prevents <a><img> same-size suppression bug)
                                      (expect (= 2 (count result)))
                                      (expect (contains? result "e1"))
                                      (expect (contains? result "e2")))))

    (it "keeps mixed-content container when it wraps a child (has own text)"

      (core/with-testing-page [_pg] (let [refs {"e1" {:role "paragraph" :mixed true :bbox {:x 0 :y 0 :width 300 :height 20}}
                                                "e2" {:role "text"      :bbox {:x 5 :y 2 :width 60  :height 16}}}
                                          result (sut/filter-annotatable refs {:show-text true})]
        ;; e1 paragraph has :mixed true (own text besides child) → not suppressed
                                      (expect (= 2 (count result)))
                                      (expect (contains? result "e1"))
                                      (expect (contains? result "e2")))))

    (it "suppresses non-mixed container even if same role"

      (core/with-testing-page [_pg] (let [refs {"e1" {:role "text" :bbox {:x 0 :y 0 :width 300 :height 20}}
                                                "e2" {:role "text" :bbox {:x 5 :y 2 :width 60  :height 16}}}
                                          result (sut/filter-annotatable refs {:show-text true})]
        ;; e1 has no :mixed flag → pure container → suppressed
                                      (expect (= 1 (count result)))
                                      (expect (contains? result "e2")))))

    (it "zero-area child does not suppress visible container"

      (core/with-testing-page [_pg] (let [refs {"e1" {:role "link" :bbox {:x 63 :y 0 :width 0 :height 0}}
                                                "e2" {:role "img"  :bbox {:x 63 :y 0 :width 132 :height 70}}}
                                          result (sut/filter-annotatable refs)]
        ;; e1 is a 0×0 hidden link inside e2 (a CSS background-image logo)
        ;; e2 must NOT be suppressed — the zero-area ghost shouldn't trigger
        ;; container dedup
                                      (expect (contains? result "e2")))))

    (it "finds a child in another grid cell than its container's corner"

      ;; The dedup reads refs from a grid by position. With this many refs it
      ;; uses the grid, and the child is far from the corner of its container.
      (core/with-testing-page [_pg] (let [filler (into {} (for [i (range 200)]
                                                            [(str "f" i) {:role "link" :bbox {:x (+ 2000 (* 50 i)) :y 3000 :width 30 :height 10}}]))
                                          refs   (assoc filler
                                                   "e1" {:role "dialog" :bbox {:x 100 :y 100 :width 600 :height 400}}
                                                   "e2" {:role "button" :bbox {:x 600 :y 450 :width 40 :height 20}})
                                          result (sut/remove-containers refs)]
                                      (expect (= 201 (count result)))
                                      (expect (not (contains? result "e1")))
                                      (expect (contains? result "e2")))))

    (it "finds a child of a container that covers more cells than there are refs"

      (core/with-testing-page [_pg] (let [refs {"e1" {:role "dialog" :bbox {:x 0 :y 0 :width 20000 :height 20000}}
                                                "e2" {:role "button" :bbox {:x 15000 :y 15000 :width 40 :height 20}}}]
                                      (expect (= ["e2"] (keys (sut/remove-containers refs)))))))

    (it "handles empty refs"

      (core/with-testing-page [_pg] (expect (= {} (sut/filter-annotatable {})))))

    (it "handles single ref"

      (core/with-testing-page [_pg] (let [refs {"e1" {:role "button" :bbox {:x 0 :y 0 :width 50 :height 20}}}]
                                      (expect (= refs (sut/filter-annotatable refs)))))))

  (describe "combined filtering (structural + containment)"
    (it "filters example.org-like structure: heading + paragraphs + link"

      (core/with-testing-page [_pg] (let [refs {"e1" {:role "heading"   :bbox {:x 0 :y 50 :width 768 :height 45}}
                                                "e2" {:role "paragraph" :bbox {:x 0 :y 97 :width 768 :height 20}}
                  ;; e3 paragraph wraps e4 link (link bbox inside paragraph bbox)
                                                "e3" {:role "paragraph" :bbox {:x 0 :y 120 :width 768 :height 25}}
                                                "e4" {:role "link"      :bbox {:x 2 :y 122 :width 80  :height 19}}}
                                          result (sut/filter-annotatable refs {:show-text true})]
        ;; e3 paragraph contains e4 link → e3 suppressed by containment dedup
        ;; heading, standalone paragraph (e2), and link all kept
                                      (expect (= 3 (count result)))
                                      (expect (contains? result "e1"))
                                      (expect (contains? result "e2"))
                                      (expect (contains? result "e4")))))))

;; =============================================================================
;; Unit Tests — viewport visibility filtering
;; =============================================================================

(defdescribe visible-refs-test
  "Unit tests for viewport-based ref filtering"
  (around [f] (core/with-testing-browser (f)))

  (describe "viewport filtering"
    (it "includes fully visible elements"

      (core/with-testing-page [_pg] (let [vp   {:width 1024 :height 768}
                                          refs {"e1" {:role "button" :bbox {:x 10 :y 20 :width 60 :height 25}}}
                                          vis  (sut/visible-refs vp refs)]
                                      (expect (= 1 (count vis)))
                                      (expect (contains? vis "e1")))))

    (it "includes partially visible elements (overlapping right edge)"

      (core/with-testing-page [_pg] (let [vp   {:width 100 :height 100}
                                          refs {"e1" {:role "button" :bbox {:x 80 :y 10 :width 60 :height 25}}}
                                          vis  (sut/visible-refs vp refs)]
                                      (expect (= 1 (count vis))))))

    (it "includes partially visible elements (overlapping bottom edge)"

      (core/with-testing-page [_pg] (let [vp   {:width 100 :height 100}
                                          refs {"e1" {:role "button" :bbox {:x 10 :y 80 :width 60 :height 50}}}
                                          vis  (sut/visible-refs vp refs)]
                                      (expect (= 1 (count vis))))))

    (it "excludes elements fully below viewport"

      (core/with-testing-page [_pg] (let [vp   {:width 1024 :height 768}
                                          refs {"e1" {:role "button" :bbox {:x 10 :y 800 :width 60 :height 25}}}
                                          vis  (sut/visible-refs vp refs)]
                                      (expect (= 0 (count vis))))))

    (it "excludes elements fully to the right of viewport"

      (core/with-testing-page [_pg] (let [vp   {:width 1024 :height 768}
                                          refs {"e1" {:role "button" :bbox {:x 1100 :y 10 :width 60 :height 25}}}
                                          vis  (sut/visible-refs vp refs)]
                                      (expect (= 0 (count vis))))))

    (it "excludes elements fully above viewport (negative y + height)"

      (core/with-testing-page [_pg] (let [vp   {:width 1024 :height 768}
                                          refs {"e1" {:role "button" :bbox {:x 10 :y -50 :width 60 :height 25}}}
                                          vis  (sut/visible-refs vp refs)]
                                      (expect (= 0 (count vis))))))

    (it "excludes elements fully to the left of viewport"

      (core/with-testing-page [_pg] (let [vp   {:width 1024 :height 768}
                                          refs {"e1" {:role "button" :bbox {:x -100 :y 10 :width 60 :height 25}}}
                                          vis  (sut/visible-refs vp refs)]
                                      (expect (= 0 (count vis))))))

    (it "filters mixed visible and offscreen refs"

      (core/with-testing-page [_pg] (let [vp   {:width 1024 :height 768}
                                          refs {"e1" {:role "button" :bbox {:x 10 :y 20 :width 60 :height 25}}
                                                "e2" {:role "link"   :bbox {:x 10 :y 800 :width 40 :height 15}}
                                                "e3" {:role "heading" :bbox {:x 10 :y 5 :width 80 :height 20}}}
                                          vis  (sut/visible-refs vp refs)]
                                      (expect (= 2 (count vis)))
                                      (expect (contains? vis "e1"))
                                      (expect (contains? vis "e3"))
                                      (expect (not (contains? vis "e2"))))))

    (it "excludes zero-size bbox"

      (core/with-testing-page [_pg] (let [vp   {:width 1024 :height 768}
                                          refs {"e1" {:role "button" :bbox {:x 10 :y 10 :width 0 :height 0}}}
                                          vis  (sut/visible-refs vp refs)]
                                      (expect (= 0 (count vis))))))

    (it "handles empty refs"

      (core/with-testing-page [_pg] (let [vp  {:width 1024 :height 768}
                                          vis (sut/visible-refs vp {})]
                                      (expect (= 0 (count vis))))))))

;; =============================================================================
;; Integration Tests — annotated-screenshot
;; =============================================================================

(defdescribe annotated-screenshot-integration-test
  "Integration tests with real Playwright screenshots"
  (around [f] (core/with-testing-browser (f)))

  (describe "annotated-screenshot with real page"

    (it "returns {:bytes :annotated} with a valid PNG and ref entries"

      (core/with-testing-page [pg] (page/navigate pg "https://example.org")
        (let [snap   (snapshot/capture-snapshot pg)
              result (sut/annotated-screenshot pg (:refs snap))
              ^bytes png (:bytes result)]
          (expect (bytes? png))
          (expect (pos? (alength png)))
          ;; :annotated is the LLM-friendly ref→label mapping
          (expect (map? (:annotated result)))
          (expect (number? (get-in result [:annotated :count])))
          (expect (vector? (get-in result [:annotated :entries])))
          ;; Entries carry ref + role + bbox so downstream tooling can map
          ;; visual labels back to @refs
          (when (pos? (get-in result [:annotated :count]))
            (let [e (first (get-in result [:annotated :entries]))]
              (expect (string? (:ref e)))
              (expect (string? (:role e)))
              (expect (map? (:bbox e)))))
          ;; Verify it's a valid PNG
          (let [img (ImageIO/read (ByteArrayInputStream. png))]
            (expect (some? img))
            (expect (pos? (.getWidth img)))
            (expect (pos? (.getHeight img)))))))

    (it "entries are sorted top→down, left→right"

      (core/with-testing-page [pg] (page/navigate pg "https://example.org")
        (let [snap    (snapshot/capture-snapshot pg)
              result  (sut/annotated-screenshot pg (:refs snap))
              entries (get-in result [:annotated :entries])]
          ;; y coordinate is non-decreasing in reading order
          (doseq [[a b] (partition 2 1 entries)]
            (let [ya (double (or (get-in a [:bbox :y]) 0))
                  yb (double (or (get-in b [:bbox :y]) 0))]
              (expect (<= ya yb)))))))

    (it "marks keep a pixel of air between them on a dense grid of tiny controls"

      ;; Regression: every label was drawn at its own box's top-left, so a row of
      ;; 13x13 checkboxes piled its labels into one unreadable stack. Then the
      ;; scorer only refused REAL overlap, so a mark was free to stop exactly on
      ;; its neighbour's edge — the numbers read as one long number, and the
      ;; sub-pixel rounding of another machine's checkbox turned that graze into
      ;; an overlap: this suite passed here and failed on CI with 19 clashing
      ;; pairs, each mark on the one a row below it. Air is the assertion now.
      (core/with-testing-page [pg]
        (page/set-content! pg (str "<html><body style='margin:0'>"
                                (apply str (for [i (range 40)]
                                             (str "<label style='display:inline-block;width:60px'>"
                                               "<input type='checkbox' id='c" i "'></label>")))
                                "</body></html>"))
        (let [snap  (snapshot/capture-snapshot pg)
              _     (sut/inject-overlays! pg (:refs snap))
              rects (page/evaluate pg
                      (str "Array.from(document.querySelectorAll('[data-spel-annotate=\"mark\"]'))"
                        ".map(function(e){var r = e.getBoundingClientRect();"
                        "return [r.left, r.top, r.right, r.bottom];})"))
              rs    (mapv (fn [r] (mapv double r)) rects)
              ;; Gap between two rectangles: positive when they are apart on some
              ;; axis, negative when they overlap on both.
              gaps  (for [i (range (count rs))
                          j (range (inc i) (count rs))
                          :let [[l1 t1 r1 b1] (nth rs i)
                                [l2 t2 r2 b2] (nth rs j)]]
                      (max (- l1 r2) (- l2 r1) (- t1 b2) (- t2 b1)))
              clash (count (filter neg? gaps))]
          (expect (> (count rs) 10))
          (expect (zero? clash))
          ;; Measured 7px here; one whole pixel is the promise, so a machine that
          ;; rounds a checkbox differently still cannot make two numbers touch.
          (expect (>= (double (apply min gaps)) 1.0))
          (sut/remove-overlays! pg))))

    (it "a mark never lands on the first words of the row it names, and buries no neighbour"

      ;; Regression: marks were only kept off each other, so on a link list with
      ;; no vertical gap every number was dropped onto the first letters of a
      ;; title — `Story number 12` rendered as `12ory number 12`, the picture
      ;; naming the rows it had made unreadable. Two figures decide it now: no
      ;; mark covers its own element's head, and no mark buries a NEIGHBOUR's
      ;; word (sitting on the tail of the element it names is free — the reader
      ;; already has that row in the `#N @ref role name` table).
      (core/with-testing-page [pg]
        (page/set-content! pg (str "<html><body style='margin:0;font:13px monospace;width:900px'>"
                                (apply str (for [i (range 25)]
                                             (str "<div style='line-height:14px'>"
                                               "<a href='#a" i "'>Story number " i " with a reasonably long title</a> "
                                               "<span>(example.com)</span></div>")))
                                "</body></html>"))
        (let [snap    (snapshot/capture-snapshot pg)
              _       (sut/inject-overlays! pg (:refs snap))
              covered (page/evaluate pg
                        (str "(function(){"
                          "var marks = Array.from(document.querySelectorAll('[data-spel-annotate=\"mark\"]'));"
                          "var own = {};"
                          "Array.from(document.querySelectorAll('[data-spel-annotate=\"box\"]')).forEach(function(b){"
                          "  own[b.getAttribute('data-spel-ref')] = b.getBoundingClientRect(); });"
                          "var tw = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null, false), n, texts = [];"
                          "while ((n = tw.nextNode())) {"
                          "  if (!n.nodeValue.trim()) continue;"
                          "  if (n.parentElement && n.parentElement.closest('[data-spel-annotate]')) continue;"
                          "  var rg = document.createRange(); rg.selectNode(n);"
                          "  var rs = rg.getClientRects();"
                          "  for (var i = 0; i < rs.length; i++) if (rs[i].width > 0 && rs[i].height > 0) texts.push(rs[i]);"
                          "}"
                          "var ov = function(a, b){ return Math.max(0, Math.min(a.right, b.right) - Math.max(a.left, b.left))"
                          "  * Math.max(0, Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top)); };"
                          "var worst = 0, buried = 0, onHead = 0;"
                          "for (var m = 0; m < marks.length; m++) {"
                          "  var a = marks[m].getBoundingClientRect(), mine = own[marks[m].getAttribute('data-spel-ref')], s = 0;"
                          "  for (var t = 0; t < texts.length; t++) {"
                          "    var o = ov(a, texts[t]); if (!o) continue;"
                          ;; Words inside the element the mark names are its own; skip them.
                          "    if (mine && ov(texts[t], mine) > 0.5 * texts[t].width * texts[t].height) continue;"
                          "    s += o;"
                          "  }"
                          "  var pct = Math.round(100 * s / (a.width * a.height));"
                          "  if (pct > 25) buried++;"
                          "  if (pct > worst) worst = pct;"
                          ;; The head is the first few characters — the ones that say which row this is.
                          "  if (mine && a.left <= mine.left + 4 && a.right >= mine.left + 4"
                          "      && a.top <= mine.top + mine.height / 2 && a.bottom >= mine.top + mine.height / 2) onHead++;"
                          "}"
                          "return [marks.length, buried, worst, onHead];})()"))
              [n buried worst on-head] (mapv long covered)]
          (expect (> n 10))
          ;; Not one number sits on the first letters of its own title.
          (expect (zero? on-head))
          ;; And none buries a neighbour's word: measured 0 of 25, worst 3%.
          (expect (zero? buried))
          (expect (<= worst 10))
          (sut/remove-overlays! pg))))

    (it "a mark wears its own box's colour, and neighbours differ"

      ;; Regression: one amber for every element meant a dense page's numbers
      ;; could not be paired with the boxes they named.
      (core/with-testing-page [pg]
        (page/set-content! pg (str "<html><body style='margin:0'>"
                                (apply str (for [i (range 4)]
                                             (str "<button style='display:block;width:120px;height:40px'>Go " i "</button>")))
                                "</body></html>"))
        (let [snap  (snapshot/capture-snapshot pg)
              _     (sut/inject-overlays! pg (:refs snap))
              pairs (page/evaluate pg
                      (str "(function(){"
                        "var out = [];"
                        "var marks = Array.from(document.querySelectorAll('[data-spel-annotate=\"mark\"]'));"
                        "for (var i = 0; i < marks.length; i++) {"
                        "  var ref = marks[i].getAttribute('data-spel-ref');"
                        "  var box = document.querySelector('[data-spel-annotate=\"box\"][data-spel-ref=\"' + ref + '\"]');"
                        "  var cs = getComputedStyle(marks[i]), bs = getComputedStyle(box);"
                        "  out.push(cs.backgroundColor + '|' + bs.borderTopColor);"
                        "}"
                        "return out;})()"))
              pairs (mapv str pairs)]
          (expect (>= (count pairs) 4))
          ;; Mark chip and box outline are the same hue, entry by entry.
          (doseq [p pairs]
            (let [[chip outline] (str/split p #"\|")]
              (expect (= chip outline))))
          ;; Numbering is in reading order, so consecutive entries never repeat.
          (expect (= (count pairs) (count (distinct pairs))))
          (sut/remove-overlays! pg))))

    (it "annotated is larger than raw screenshot"

      (core/with-testing-page [pg]
        (example/route! pg)
        (page/navigate pg "https://example.org")
        (let [snap             (snapshot/capture-snapshot pg)
              raw              (page/screenshot pg)
              ^bytes annotated (:bytes (sut/annotated-screenshot pg (:refs snap)))]
          (expect (> (alength annotated) (alength raw))))))))

;; =============================================================================
;; Integration Tests — save-annotated-screenshot!
;; =============================================================================

(defdescribe save-annotated-screenshot-test
  "Integration tests for saving annotated screenshots to file"
  (around [f] (core/with-testing-browser (f)))

  (describe "save to file"

    (it "writes a non-empty PNG file and returns {:path :size :annotated}"

      (core/with-testing-page [pg] (page/navigate pg "https://example.org")
        (let [snap     (snapshot/capture-snapshot pg)
              tmp-file (File/createTempFile "annotate-test-" ".png")
              path     (.getAbsolutePath tmp-file)]
          (try
            (let [result (sut/save-annotated-screenshot! pg (:refs snap) path)]
              (expect (.exists tmp-file))
              (expect (pos? (.length tmp-file)))
              (expect (= path (:path result)))
              (expect (pos? (:size result)))
              (expect (number? (get-in result [:annotated :count])))
              ;; Verify it's a valid image
              (let [img (ImageIO/read tmp-file)]
                (expect (some? img))))
            (finally
              (.delete tmp-file))))))))

;; =============================================================================
;; Integration Tests — scoped annotations
;; =============================================================================

(defdescribe scoped-annotation-test
  "Integration tests for scoped annotation support"
  (around [f] (core/with-testing-browser (f)))

  (describe "scoped inject-overlays! with CSS selector"

    (it "annotates fewer elements when scoped to a subtree"

      (core/with-testing-page [pg] (page/navigate pg "https://example.org")
        (let [snap     (snapshot/capture-snapshot pg)
              refs     (:refs snap)
              full-n   (:count (sut/inject-overlays! pg refs))
              _        (sut/remove-overlays! pg)
            ;; Scope to just the body > div (inner content container)
              scoped-n (:count (sut/inject-overlays! pg refs {:scope "div > p"}))]
          (sut/remove-overlays! pg)
        ;; Scoped should annotate fewer (or equal) elements
          (expect (<= scoped-n full-n)))))

    (it "returns {:count 0 :entries []} when scope selector matches nothing"

      (core/with-testing-page [pg] (page/navigate pg "https://example.org")
        (let [snap   (snapshot/capture-snapshot pg)
              result (sut/inject-overlays! pg (:refs snap) {:scope "#nonexistent-element"})]
          (expect (= 0 (:count result)))
          (expect (= [] (:entries result)))))))

  (describe "scoped snapshot via capture-snapshot :scope"

    (it "captures fewer refs when scoped"

      (core/with-testing-page [pg] (page/navigate pg "https://example.org")
        (let [full-snap   (snapshot/capture-snapshot pg)
              scoped-snap (snapshot/capture-snapshot pg {:scope "div > p"})]
        ;; Scoped snapshot should have fewer (or equal) refs
          (expect (<= (count (:refs scoped-snap)) (count (:refs full-snap)))))))

    (it "returns empty snapshot when scope matches nothing"

      (core/with-testing-page [pg] (page/navigate pg "https://example.org")
        (let [snap (snapshot/capture-snapshot pg {:scope "#nonexistent"})]
          (expect (nil? (:tree snap)))
          (expect (= 0 (count (:refs snap))))
          (expect (= 0 (:counter snap)))))))

  (describe "scoped annotated-screenshot"

    (it "produces valid PNG with scoped annotations"

      (core/with-testing-page [pg] (page/navigate pg "https://example.org")
        (let [snap       (snapshot/capture-snapshot pg)
              result     (sut/annotated-screenshot pg (:refs snap) {:scope "body"})
              ^bytes png (:bytes result)]
          (expect (bytes? png))
          (expect (pos? (alength png)))
          (expect (map? (:annotated result)))
          (let [img (ImageIO/read (ByteArrayInputStream. png))]
            (expect (some? img))))))))
